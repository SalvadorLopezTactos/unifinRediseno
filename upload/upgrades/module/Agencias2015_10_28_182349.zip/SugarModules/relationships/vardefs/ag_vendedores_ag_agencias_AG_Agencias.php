<?php
// created: 2015-10-28 18:23:48
$dictionary["AG_Agencias"]["fields"]["ag_vendedores_ag_agencias"] = array (
  'name' => 'ag_vendedores_ag_agencias',
  'type' => 'link',
  'relationship' => 'ag_vendedores_ag_agencias',
  'source' => 'non-db',
  'module' => 'AG_Vendedores',
  'bean_name' => 'AG_Vendedores',
  'vname' => 'LBL_AG_VENDEDORES_AG_AGENCIAS_FROM_AG_AGENCIAS_TITLE',
  'id_name' => 'ag_vendedores_ag_agenciasag_agencias_ida',
  'link-type' => 'many',
  'side' => 'left',
);

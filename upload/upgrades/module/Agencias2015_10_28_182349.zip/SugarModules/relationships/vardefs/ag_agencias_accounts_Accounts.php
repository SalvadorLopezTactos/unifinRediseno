<?php
// created: 2015-10-28 18:23:49
$dictionary["Account"]["fields"]["ag_agencias_accounts"] = array (
  'name' => 'ag_agencias_accounts',
  'type' => 'link',
  'relationship' => 'ag_agencias_accounts',
  'source' => 'non-db',
  'module' => 'AG_Agencias',
  'bean_name' => 'AG_Agencias',
  'vname' => 'LBL_AG_AGENCIAS_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'ag_agencias_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);

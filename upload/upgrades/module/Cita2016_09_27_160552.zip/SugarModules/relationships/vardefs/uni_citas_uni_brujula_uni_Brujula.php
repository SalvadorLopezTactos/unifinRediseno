<?php
// created: 2016-09-27 16:05:52
$dictionary["uni_Brujula"]["fields"]["uni_citas_uni_brujula"] = array (
  'name' => 'uni_citas_uni_brujula',
  'type' => 'link',
  'relationship' => 'uni_citas_uni_brujula',
  'source' => 'non-db',
  'module' => 'uni_Citas',
  'bean_name' => 'uni_Citas',
  'vname' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_BRUJULA_TITLE',
  'id_name' => 'uni_citas_uni_brujulauni_brujula_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
 // created: 2016-09-27 16:05:52
$layout_defs["uni_Brujula"]["subpanel_setup"]['uni_citas_uni_brujula'] = array (
  'order' => 100,
  'module' => 'uni_Citas',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'get_subpanel_data' => 'uni_citas_uni_brujula',
);

<?php
// created: 2016-09-16 08:55:23
$viewdefs['uni_Brujula']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);
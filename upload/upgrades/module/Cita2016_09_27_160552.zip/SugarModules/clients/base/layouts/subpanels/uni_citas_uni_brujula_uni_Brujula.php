<?php
// created: 2016-09-16 08:55:22
$viewdefs['uni_Brujula']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);

$viewdefs['uni_Brujula']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_UNI_CITAS_UNI_BRUJULA_FROM_UNI_CITAS_TITLE',
  'context' => 
  array (
    'link' => 'uni_citas_uni_brujula',
  ),
);
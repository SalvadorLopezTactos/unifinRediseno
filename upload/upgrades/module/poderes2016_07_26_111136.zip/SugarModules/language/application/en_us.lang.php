<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['uni_poderes'] = 'Poderes';
$app_list_strings['moduleListSingular']['uni_poderes'] = 'Poderes';
$app_list_strings['poderes_list'][1] = 'PLEITOS Y COBRANZAS';
$app_list_strings['poderes_list'][2] = 'ADMINISTRACION';
$app_list_strings['poderes_list'][3] = 'DOMINIO';
$app_list_strings['poderes_list'][4] = 'SUSCRIBIR TÍTULOS DE CREDITO';
$app_list_strings['poderes_list'][5] = 'OTORGAR Y REVOCAR PODERES';
$app_list_strings['forma_poder_list']['I'] = 'INDIVIDUAL';
$app_list_strings['forma_poder_list']['M'] = 'MANCOMUNADA';
$app_list_strings['estatus_poder'][1] = 'VIGENTE';
$app_list_strings['estatus_poder'][0] = 'NO VIGENTE';

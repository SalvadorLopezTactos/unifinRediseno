<?php
$module_name = 'uni_poderes';
$viewdefs[$module_name] = 
array (
  'base' => 
  array (
    'view' => 
    array (
      'record' => 
      array (
        'panels' => 
        array (
          0 => 
          array (
            'name' => 'panel_header',
            'label' => 'LBL_RECORD_HEADER',
            'header' => true,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'picture',
                'type' => 'avatar',
                'width' => 42,
                'height' => 42,
                'dismiss_label' => true,
                'readonly' => true,
              ),
              1 => 'name',
              2 => 
              array (
                'name' => 'favorite',
                'label' => 'LBL_FAVORITE',
                'type' => 'favorite',
                'readonly' => true,
                'dismiss_label' => true,
              ),
              3 => 
              array (
                'name' => 'follow',
                'label' => 'LBL_FOLLOW',
                'type' => 'follow',
                'readonly' => true,
                'dismiss_label' => true,
              ),
            ),
          ),
          1 => 
          array (
            'newTab' => false,
            'panelDefault' => 'expanded',
            'name' => 'LBL_RECORDVIEW_PANEL2',
            'label' => 'LBL_RECORDVIEW_PANEL2',
            'columns' => 2,
            'labelsOnTop' => 1,
            'placeholders' => 1,
            'fields' => 
            array (
              0 => 
              array (
                'name' => 'apoderado',
                'studio' => 'visible',
                'label' => 'LBL_APODERADO',
              ),
              1 => 
              array (
                'name' => 'puesto',
                'label' => 'LBL_PUESTO',
              ),
              2 => 
              array (
                'name' => 'poderes',
                'studio' => 'visible',
                'label' => 'LBL_PODERES',
              ),
              3 => 
              array (
                'name' => 'estatus',
                'studio' => 'visible',
                'label' => 'LBL_ESTATUS',
              ),
              4 => 
              array (
                'name' => 'forma',
                'studio' => 'visible',
                'label' => 'LBL_FORMA',
              ),
              5 => 
              array (
                'name' => 'mancomunado',
                'studio' => 'visible',
                'label' => 'LBL_MANCOMUNADO',
              ),
              6 => 
              array (
                'name' => 'limitaciones',
                'studio' => 'visible',
                'label' => 'LBL_LIMITACIONES',
                'span' => 12,
              ),
            ),
          ),
        ),
        'templateMeta' => 
        array (
          'useTabs' => false,
        ),
      ),
    ),
  ),
);

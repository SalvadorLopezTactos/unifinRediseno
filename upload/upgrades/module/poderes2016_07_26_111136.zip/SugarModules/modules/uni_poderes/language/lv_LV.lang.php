<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Darba grupa',
  'LBL_TEAMS' => 'Darba grupas',
  'LBL_TEAM_ID' => 'Darba grupas ID',
  'LBL_ASSIGNED_TO_ID' => 'Piešķirts lietotājam ar Id',
  'LBL_ASSIGNED_TO_NAME' => 'Piešķirts lietotājam',
  'LBL_CREATED' => 'Izveidoja',
  'LBL_CREATED_ID' => 'Izveidotāja ID',
  'LBL_CREATED_USER' => 'Izveidoja',
  'LBL_DATE_ENTERED' => 'Izveidots',
  'LBL_DATE_MODIFIED' => 'Modificēts',
  'LBL_DELETED' => 'Dzēsts',
  'LBL_DESCRIPTION' => 'Apraksts',
  'LBL_DOC_OWNER' => 'Dokumenta īpašnieks',
  'LBL_EDIT_BUTTON' => 'Rediģēt',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Nosaukums',
  'LBL_MODIFIED' => 'Modificēja',
  'LBL_MODIFIED_ID' => 'Modificētāja ID',
  'LBL_MODIFIED_NAME' => 'Modificēja',
  'LBL_MODIFIED_USER' => 'Modificēja lietotājs',
  'LBL_NAME' => 'Nosaukums',
  'LBL_REMOVE' => 'Noņemt',
  'LBL_USER_FAVORITES' => 'Lietotāji atzīmēja',
  'LBL_LIST_FORM_TITLE' => 'Poderes Saraksts',
  'LBL_MODULE_NAME' => 'Poderes',
  'LBL_MODULE_TITLE' => 'Poderes',
  'LBL_MODULE_NAME_SINGULAR' => 'Poderes',
  'LBL_HOMEPAGE_TITLE' => 'Mans Poderes',
  'LNK_NEW_RECORD' => 'Izveidot Poderes',
  'LNK_LIST' => 'Skats Poderes',
  'LNK_IMPORT_UNI_PODERES' => 'Importar Poderes',
  'LBL_SEARCH_FORM_TITLE' => 'Meklēt Poderes',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Aplūkot vēsturi',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Darbības',
  'LBL_UNI_PODERES_SUBPANEL_TITLE' => 'Poderes',
  'LBL_NEW_FORM_TITLE' => 'Jauns Poderes',
  'LNK_IMPORT_VCARD' => 'Importar Poderes vCard',
  'LBL_IMPORT' => 'Importar Poderes',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Poderes record by importing a vCard from your file system.',
  'LBL_APODERADO_ACCOUNT_ID' => 'Representante legal o Apoderado (relacionado Persona ID)',
  'LBL_APODERADO' => 'Representante legal o Apoderado',
  'LBL_PUESTO' => 'Puesto',
  'LBL_PODERES' => 'Poderes',
  'LBL_FORMA' => 'Ejerce de forma:',
  'LBL_MANCOMUNADO_ACCOUNT_ID' => 'Mancomunado con: (relacionado Persona ID)',
  'LBL_MANCOMUNADO' => 'Mancomunado con:',
  'LBL_LIMITACIONES' => 'Limitaciones',
  'LBL_NO_DICTAMEN' => 'Dictamen',
  'LBL_CONSECUTIVO' => 'Consecutivo',
  'LBL_ESTATUS' => 'Estatus del poder',
);
<?php
// created: 2016-03-08 08:50:40
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opportunities',
  ),
);
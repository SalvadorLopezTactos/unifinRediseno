<?php
// created: 2016-03-08 08:47:08
$viewdefs['Opera_Operaciones']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'context' => 
  array (
    'link' => 'lev_condicionesfinancieras_opera_operaciones',
  ),
);
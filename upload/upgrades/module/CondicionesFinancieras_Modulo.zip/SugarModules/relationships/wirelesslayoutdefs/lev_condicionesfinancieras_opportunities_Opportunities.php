<?php
 // created: 2016-04-03 12:50:00
$layout_defs["Opportunities"]["subpanel_setup"]['lev_condicionesfinancieras_opportunities'] = array (
  'order' => 100,
  'module' => 'lev_CondicionesFinancieras',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'get_subpanel_data' => 'lev_condicionesfinancieras_opportunities',
);

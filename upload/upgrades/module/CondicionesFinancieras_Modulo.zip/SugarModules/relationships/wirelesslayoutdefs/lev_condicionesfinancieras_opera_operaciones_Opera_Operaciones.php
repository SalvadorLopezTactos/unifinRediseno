<?php
 // created: 2016-03-08 08:47:08
$layout_defs["Opera_Operaciones"]["subpanel_setup"]['lev_condicionesfinancieras_opera_operaciones'] = array (
  'order' => 100,
  'module' => 'lev_CondicionesFinancieras',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'get_subpanel_data' => 'lev_condicionesfinancieras_opera_operaciones',
);

<?php
// created: 2016-04-03 12:50:00
$dictionary["Opportunity"]["fields"]["lev_condicionesfinancieras_opportunities"] = array (
  'name' => 'lev_condicionesfinancieras_opportunities',
  'type' => 'link',
  'relationship' => 'lev_condicionesfinancieras_opportunities',
  'source' => 'non-db',
  'module' => 'lev_CondicionesFinancieras',
  'bean_name' => 'lev_CondicionesFinancieras',
  'vname' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'lev_condicionesfinancieras_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
// created: 2016-03-08 08:47:08
$dictionary["lev_CondicionesFinancieras"]["fields"]["lev_condicionesfinancieras_opera_operaciones"] = array (
  'name' => 'lev_condicionesfinancieras_opera_operaciones',
  'type' => 'link',
  'relationship' => 'lev_condicionesfinancieras_opera_operaciones',
  'source' => 'non-db',
  'module' => 'Opera_Operaciones',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'id_name' => 'lev_condicdf1aaciones_ida',
  'link-type' => 'one',
);
$dictionary["lev_CondicionesFinancieras"]["fields"]["lev_condicionesfinancieras_opera_operaciones_name"] = array (
  'name' => 'lev_condicionesfinancieras_opera_operaciones_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_OPERA_OPERACIONES_TITLE',
  'save' => true,
  'id_name' => 'lev_condicdf1aaciones_ida',
  'link' => 'lev_condicionesfinancieras_opera_operaciones',
  'table' => 'opera_operaciones',
  'module' => 'Opera_Operaciones',
  'rname' => 'name',
);
$dictionary["lev_CondicionesFinancieras"]["fields"]["lev_condicdf1aaciones_ida"] = array (
  'name' => 'lev_condicdf1aaciones_ida',
  'type' => 'id',
  'source' => 'non-db',
  'vname' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE_ID',
  'id_name' => 'lev_condicdf1aaciones_ida',
  'link' => 'lev_condicionesfinancieras_opera_operaciones',
  'table' => 'opera_operaciones',
  'module' => 'Opera_Operaciones',
  'rname' => 'id',
  'reportable' => false,
  'side' => 'right',
  'massupdate' => false,
  'duplicate_merge' => 'disabled',
  'hideacl' => true,
);

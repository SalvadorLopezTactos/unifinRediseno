<?php
// created: 2016-03-08 08:47:08
$dictionary["Opera_Operaciones"]["fields"]["lev_condicionesfinancieras_opera_operaciones"] = array (
  'name' => 'lev_condicionesfinancieras_opera_operaciones',
  'type' => 'link',
  'relationship' => 'lev_condicionesfinancieras_opera_operaciones',
  'source' => 'non-db',
  'module' => 'lev_CondicionesFinancieras',
  'bean_name' => false,
  'vname' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_OPERA_OPERACIONES_TITLE',
  'id_name' => 'lev_condicdf1aaciones_ida',
  'link-type' => 'many',
  'side' => 'left',
);

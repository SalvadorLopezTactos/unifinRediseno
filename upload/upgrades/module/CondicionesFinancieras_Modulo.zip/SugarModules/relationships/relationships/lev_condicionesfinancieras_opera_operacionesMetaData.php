<?php
// created: 2016-03-08 08:47:07
$dictionary["lev_condicionesfinancieras_opera_operaciones"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'lev_condicionesfinancieras_opera_operaciones' => 
    array (
      'lhs_module' => 'Opera_Operaciones',
      'lhs_table' => 'opera_operaciones',
      'lhs_key' => 'id',
      'rhs_module' => 'lev_CondicionesFinancieras',
      'rhs_table' => 'lev_condicionesfinancieras',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'lev_condicionesfinancieras_opera_operaciones_c',
      'join_key_lhs' => 'lev_condicdf1aaciones_ida',
      'join_key_rhs' => 'lev_condic06a3ncieras_idb',
    ),
  ),
  'table' => 'lev_condicionesfinancieras_opera_operaciones_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'lev_condicdf1aaciones_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'lev_condic06a3ncieras_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'lev_condicionesfinancieras_opera_operacionesspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'lev_condicionesfinancieras_opera_operaciones_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'lev_condicdf1aaciones_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'lev_condicionesfinancieras_opera_operaciones_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'lev_condic06a3ncieras_idb',
      ),
    ),
  ),
);
<?php
 // created: 2016-03-08 08:47:07
$layout_defs["Opera_Operaciones"]["subpanel_setup"]['lev_condicionesfinancieras_opera_operaciones'] = array (
  'order' => 100,
  'module' => 'lev_CondicionesFinancieras',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LEV_CONDICIONESFINANCIERAS_OPERA_OPERACIONES_FROM_LEV_CONDICIONESFINANCIERAS_TITLE',
  'get_subpanel_data' => 'lev_condicionesfinancieras_opera_operaciones',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
  ),
);

<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Týmy',
  'LBL_TEAMS' => 'Týmy',
  'LBL_TEAM_ID' => 'ID týmu',
  'LBL_ASSIGNED_TO_ID' => 'Přidělené ID uživatele',
  'LBL_ASSIGNED_TO_NAME' => 'Uživatel',
  'LBL_CREATED' => 'Vytvořeno',
  'LBL_CREATED_ID' => 'Vytvořeno (ID)',
  'LBL_CREATED_USER' => 'Vytvořeno uživatelem',
  'LBL_DATE_ENTERED' => 'Datum vytvoření',
  'LBL_DATE_MODIFIED' => 'Datum změny',
  'LBL_DELETED' => 'Smazáno',
  'LBL_DESCRIPTION' => 'Popis',
  'LBL_DOC_OWNER' => 'Vlastník dokumentu',
  'LBL_EDIT_BUTTON' => 'Upravit',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Jméno',
  'LBL_MODIFIED' => 'Změnil',
  'LBL_MODIFIED_ID' => 'Změněno podle ID',
  'LBL_MODIFIED_NAME' => 'Změněno kým:',
  'LBL_MODIFIED_USER' => 'Změněno uživatelem',
  'LBL_NAME' => 'Jméno',
  'LBL_REMOVE' => 'Odstranit',
  'LBL_USER_FAVORITES' => 'Uživatelé, jejichž je oblíbeným',
  'LBL_LIST_FORM_TITLE' => 'Condiciones Iniciales Seznam',
  'LBL_MODULE_NAME' => 'Condiciones Iniciales',
  'LBL_MODULE_TITLE' => 'Condiciones Iniciales',
  'LBL_MODULE_NAME_SINGULAR' => 'Condicion Inicial',
  'LBL_HOMEPAGE_TITLE' => 'Moje Condiciones Iniciales',
  'LNK_NEW_RECORD' => 'Přidat Condicion Inicial',
  'LNK_LIST' => 'Zobrazit Condiciones Iniciales',
  'LNK_IMPORT_UNI_CONDICIONES_INICIALES' => 'Importar Condicion Inicial',
  'LBL_SEARCH_FORM_TITLE' => 'Hledat Condicion Inicial',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historie',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktivity',
  'LBL_UNI_CONDICIONES_INICIALES_SUBPANEL_TITLE' => 'Condiciones Iniciales',
  'LBL_NEW_FORM_TITLE' => 'Nový Condicion Inicial',
  'LNK_IMPORT_VCARD' => 'Importar Condicion Inicial vCard',
  'LBL_IMPORT' => 'Importar Condiciones Iniciales',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Condicion Inicial record by importing a vCard from your file system.',
  'LBL_ACTIVO' => 'Activo',
  'LBL_CAMPO_DESTINO' => 'campo destino',
  'LBL_RANGO_MINIMO' => 'Rango Minimo',
  'LBL_RANGO_MAXIMO' => 'Rango Maximo',
  'LBL_CAMPO_DESTINO_MINIMO' => 'Campo Destino (Minimo)',
  'LBL_CAMPO_DESTINO_MAXIMO' => 'Campo Destino (Maximo)',
  'LBL_PLAZO' => 'plazo',
);
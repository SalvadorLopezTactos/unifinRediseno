<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Команды',
  'LBL_TEAMS' => 'Команды',
  'LBL_TEAM_ID' => 'Id Команды',
  'LBL_ASSIGNED_TO_ID' => 'Ответственный (-ая)',
  'LBL_ASSIGNED_TO_NAME' => 'Ответственный (-ая)',
  'LBL_CREATED' => 'Создано',
  'LBL_CREATED_ID' => 'Создано (Id)',
  'LBL_CREATED_USER' => 'Создано',
  'LBL_DATE_ENTERED' => 'Дата создания',
  'LBL_DATE_MODIFIED' => 'Дата изменения',
  'LBL_DELETED' => 'Удалено',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DOC_OWNER' => 'Владелец Документа',
  'LBL_EDIT_BUTTON' => 'Правка',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Название',
  'LBL_MODIFIED' => 'Изменено',
  'LBL_MODIFIED_ID' => 'Изменено (Id)',
  'LBL_MODIFIED_NAME' => 'Изменено',
  'LBL_MODIFIED_USER' => 'Изменено',
  'LBL_NAME' => 'Название',
  'LBL_REMOVE' => 'Удалить',
  'LBL_USER_FAVORITES' => 'Пользователи, которые добавили в Избранное',
  'LBL_LIST_FORM_TITLE' => 'Condiciones Iniciales Список',
  'LBL_MODULE_NAME' => 'Condiciones Iniciales',
  'LBL_MODULE_TITLE' => 'Condiciones Iniciales',
  'LBL_MODULE_NAME_SINGULAR' => 'Condicion Inicial',
  'LBL_HOMEPAGE_TITLE' => 'Моя Condiciones Iniciales',
  'LNK_NEW_RECORD' => 'Создать Condicion Inicial',
  'LNK_LIST' => 'Просмотр Condiciones Iniciales',
  'LNK_IMPORT_UNI_CONDICIONES_INICIALES' => 'Importar Condicion Inicial',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск Condicion Inicial',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'История',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Мероприятия',
  'LBL_UNI_CONDICIONES_INICIALES_SUBPANEL_TITLE' => 'Condiciones Iniciales',
  'LBL_NEW_FORM_TITLE' => 'Новая Condicion Inicial',
  'LNK_IMPORT_VCARD' => 'Importar Condicion Inicial vCard',
  'LBL_IMPORT' => 'Importar Condiciones Iniciales',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Condicion Inicial record by importing a vCard from your file system.',
  'LBL_ACTIVO' => 'Activo',
  'LBL_CAMPO_DESTINO' => 'campo destino',
  'LBL_RANGO_MINIMO' => 'Rango Minimo',
  'LBL_RANGO_MAXIMO' => 'Rango Maximo',
  'LBL_CAMPO_DESTINO_MINIMO' => 'Campo Destino (Minimo)',
  'LBL_CAMPO_DESTINO_MAXIMO' => 'Campo Destino (Maximo)',
  'LBL_PLAZO' => 'plazo',
);
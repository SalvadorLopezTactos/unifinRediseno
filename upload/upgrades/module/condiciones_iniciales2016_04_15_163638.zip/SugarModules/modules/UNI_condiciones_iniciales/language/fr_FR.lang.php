<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipe',
  'LBL_TEAMS' => 'Equipes',
  'LBL_TEAM_ID' => 'Equipe (ID)',
  'LBL_ASSIGNED_TO_ID' => 'Assigné à (ID)',
  'LBL_ASSIGNED_TO_NAME' => 'Assigné à',
  'LBL_CREATED' => 'Créé par',
  'LBL_CREATED_ID' => 'Créé par (ID)',
  'LBL_CREATED_USER' => 'Créé par',
  'LBL_DATE_ENTERED' => 'Date de création',
  'LBL_DATE_MODIFIED' => 'Date de modification',
  'LBL_DELETED' => 'Supprimé',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DOC_OWNER' => 'Propriétaire du document',
  'LBL_EDIT_BUTTON' => 'Editer',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_MODIFIED' => 'Modifié par',
  'LBL_MODIFIED_ID' => 'Modifié par (ID)',
  'LBL_MODIFIED_NAME' => 'Modifié par',
  'LBL_MODIFIED_USER' => 'Modifié par',
  'LBL_NAME' => 'Nom',
  'LBL_REMOVE' => 'Supprimer',
  'LBL_USER_FAVORITES' => 'Favoris pour les utilisateurs suivants',
  'LBL_LIST_FORM_TITLE' => 'Condiciones Iniciales Liste',
  'LBL_MODULE_NAME' => 'Condiciones Iniciales',
  'LBL_MODULE_TITLE' => 'Condiciones Iniciales',
  'LBL_MODULE_NAME_SINGULAR' => 'Condicion Inicial',
  'LBL_HOMEPAGE_TITLE' => 'Mes Condiciones Iniciales',
  'LNK_NEW_RECORD' => 'Créer Condicion Inicial',
  'LNK_LIST' => 'Vue Condiciones Iniciales',
  'LNK_IMPORT_UNI_CONDICIONES_INICIALES' => 'Importar Condicion Inicial',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Condicion Inicial',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Voir l&#39;Historique',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activités',
  'LBL_UNI_CONDICIONES_INICIALES_SUBPANEL_TITLE' => 'Condiciones Iniciales',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Condicion Inicial',
  'LNK_IMPORT_VCARD' => 'Importar Condicion Inicial vCard',
  'LBL_IMPORT' => 'Importar Condiciones Iniciales',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Condicion Inicial record by importing a vCard from your file system.',
  'LBL_ACTIVO' => 'Activo',
  'LBL_CAMPO_DESTINO' => 'campo destino',
  'LBL_RANGO_MINIMO' => 'Rango Minimo',
  'LBL_RANGO_MAXIMO' => 'Rango Maximo',
  'LBL_CAMPO_DESTINO_MINIMO' => 'Campo Destino (Minimo)',
  'LBL_CAMPO_DESTINO_MAXIMO' => 'Campo Destino (Maximo)',
  'LBL_PLAZO' => 'plazo',
);
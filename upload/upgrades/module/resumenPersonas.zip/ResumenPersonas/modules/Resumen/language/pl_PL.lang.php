<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Przypisano do (ID użytkownika)',
  'LBL_ASSIGNED_TO_NAME' => 'Przydzielono do',
  'LBL_TAGS_LINK' => 'Tagi',
  'LBL_TAGS' => 'Tagi',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data utworzenia',
  'LBL_DATE_MODIFIED' => 'Data modyfikacji',
  'LBL_MODIFIED' => 'Zmodyfikowano przez',
  'LBL_MODIFIED_ID' => 'Zmodyfikowano przez (ID)',
  'LBL_MODIFIED_NAME' => 'Zmodyfikowano przez (nazwa)',
  'LBL_CREATED' => 'Utworzono przez',
  'LBL_CREATED_ID' => 'Utworzone przez (ID)',
  'LBL_DOC_OWNER' => 'Właściciel dokumentu',
  'LBL_USER_FAVORITES' => 'Użytkownicy, którzy dodali rekord do ulubionych',
  'LBL_DESCRIPTION' => 'Opis',
  'LBL_DELETED' => 'Usunięto',
  'LBL_NAME' => 'Nazwa',
  'LBL_CREATED_USER' => 'Utworzono przez',
  'LBL_MODIFIED_USER' => 'Zmodyfikowane przez',
  'LBL_LIST_NAME' => 'Nazwa',
  'LBL_EDIT_BUTTON' => 'Edytuj',
  'LBL_REMOVE' => 'Usuń',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Zmodyfikowano przez (nazwa)',
  'LBL_TEAM' => 'Zespoły',
  'LBL_TEAMS' => 'Zespoły',
  'LBL_TEAM_ID' => 'ID zespołu',
  'LBL_LIST_FORM_TITLE' => 'Resumen Lista',
  'LBL_MODULE_NAME' => 'Resumen',
  'LBL_MODULE_TITLE' => 'Resumen',
  'LBL_MODULE_NAME_SINGULAR' => 'Resumen',
  'LBL_HOMEPAGE_TITLE' => 'Moje Resumen',
  'LNK_NEW_RECORD' => 'Utwórz Resumen',
  'LNK_LIST' => 'Widok Resumen',
  'LNK_IMPORT_TCT02_RESUMEN' => 'Importar Resumen',
  'LBL_SEARCH_FORM_TITLE' => 'Wyszukiwanie Resumen',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Wyświetl historię',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Panel aktywności',
  'LBL_TCT02_RESUMEN_SUBPANEL_TITLE' => 'Resumen',
  'LBL_NEW_FORM_TITLE' => 'Nowy Resumen',
  'LNK_IMPORT_VCARD' => 'Importar Resumen vCard',
  'LBL_IMPORT' => 'Importar Resumen',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Resumen record by importing a vCard from your file system.',
  'LBL_ID_PERSONA' => 'Id Persona',
  'LBL_LEASING_FECHA_PAGO' => 'Leasing Fecha pago',
  'LBL_LEASING_ANEXOS_ACTIVOS' => 'Leasing Anexos activos',
  'LBL_LEASING_ANEXOS_HISTORICOS' => 'Leasing Anexos históricos',
  'LBL_FACTORING_FECHA_PAGO' => 'Factoring Fecha pago',
  'LBL_FACTORING_ANEXOS_ACTIVOS' => 'Factoring Anexos activos',
  'LBL_FACTORING_ANEXOS_HISTORICOS' => 'Factoring Anexos históricos',
  'LBL_CAUTO_FECHA_PAGO' => 'C.Auto Fecha pago',
  'LBL_CAUTO_ANEXOS_ACTIVOS' => 'C.Auto Anexos activos',
  'LBL_CAUTO_ANEXOS_HISTORICOS' => 'C.Auto Anexos históricos',
);
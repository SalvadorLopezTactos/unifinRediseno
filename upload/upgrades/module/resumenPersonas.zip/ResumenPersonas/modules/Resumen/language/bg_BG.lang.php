<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Отговорник',
  'LBL_ASSIGNED_TO_NAME' => 'Потребител',
  'LBL_TAGS_LINK' => 'Етикети',
  'LBL_TAGS' => 'Етикети',
  'LBL_ID' => 'Идентификатор',
  'LBL_DATE_ENTERED' => 'Създадено на',
  'LBL_DATE_MODIFIED' => 'Модифицирано на',
  'LBL_MODIFIED' => 'Модифицирано от',
  'LBL_MODIFIED_ID' => 'Модифицирано от',
  'LBL_MODIFIED_NAME' => 'Модифицирано от',
  'LBL_CREATED' => 'Създадено от',
  'LBL_CREATED_ID' => 'Създадено от',
  'LBL_DOC_OWNER' => 'Собственик на документа',
  'LBL_USER_FAVORITES' => 'Потребители които харесват',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DELETED' => 'Изтрити',
  'LBL_NAME' => 'Име',
  'LBL_CREATED_USER' => 'Създадено от',
  'LBL_MODIFIED_USER' => 'Модифицирано от',
  'LBL_LIST_NAME' => 'Име',
  'LBL_EDIT_BUTTON' => 'Редактирай',
  'LBL_REMOVE' => 'Премахни',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Модифицирано от',
  'LBL_TEAM' => 'Екип',
  'LBL_TEAMS' => 'Екип',
  'LBL_TEAM_ID' => 'Екип',
  'LBL_LIST_FORM_TITLE' => 'Resumen Списък',
  'LBL_MODULE_NAME' => 'Resumen',
  'LBL_MODULE_TITLE' => 'Resumen',
  'LBL_MODULE_NAME_SINGULAR' => 'Resumen',
  'LBL_HOMEPAGE_TITLE' => 'Мои Resumen',
  'LNK_NEW_RECORD' => 'Създай Resumen',
  'LNK_LIST' => 'Изглед Resumen',
  'LNK_IMPORT_TCT02_RESUMEN' => 'Importar Resumen',
  'LBL_SEARCH_FORM_TITLE' => 'Търси Resumen',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'История',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Дейности',
  'LBL_TCT02_RESUMEN_SUBPANEL_TITLE' => 'Resumen',
  'LBL_NEW_FORM_TITLE' => 'Нов Resumen',
  'LNK_IMPORT_VCARD' => 'Importar Resumen vCard',
  'LBL_IMPORT' => 'Importar Resumen',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Resumen record by importing a vCard from your file system.',
  'LBL_ID_PERSONA' => 'Id Persona',
  'LBL_LEASING_FECHA_PAGO' => 'Leasing Fecha pago',
  'LBL_LEASING_ANEXOS_ACTIVOS' => 'Leasing Anexos activos',
  'LBL_LEASING_ANEXOS_HISTORICOS' => 'Leasing Anexos históricos',
  'LBL_FACTORING_FECHA_PAGO' => 'Factoring Fecha pago',
  'LBL_FACTORING_ANEXOS_ACTIVOS' => 'Factoring Anexos activos',
  'LBL_FACTORING_ANEXOS_HISTORICOS' => 'Factoring Anexos históricos',
  'LBL_CAUTO_FECHA_PAGO' => 'C.Auto Fecha pago',
  'LBL_CAUTO_ANEXOS_ACTIVOS' => 'C.Auto Anexos activos',
  'LBL_CAUTO_ANEXOS_HISTORICOS' => 'C.Auto Anexos históricos',
);
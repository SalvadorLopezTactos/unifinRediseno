<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Tildelt bruker Id',
  'LBL_ASSIGNED_TO_NAME' => 'Tildelt til',
  'LBL_TAGS_LINK' => 'Etiketter',
  'LBL_TAGS' => 'Etiketter',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Opprettet dato',
  'LBL_DATE_MODIFIED' => 'Endret Dato',
  'LBL_MODIFIED' => 'Endret av',
  'LBL_MODIFIED_ID' => 'Endret av Id',
  'LBL_MODIFIED_NAME' => 'Endret av Navn',
  'LBL_CREATED' => 'Opprettet av',
  'LBL_CREATED_ID' => 'Opprettet av Id',
  'LBL_DOC_OWNER' => 'Dokumenteier',
  'LBL_USER_FAVORITES' => 'Brukere som favoriserer',
  'LBL_DESCRIPTION' => 'Beskrivelse',
  'LBL_DELETED' => 'Slettet',
  'LBL_NAME' => 'Navn',
  'LBL_CREATED_USER' => 'Opprettet av bruker',
  'LBL_MODIFIED_USER' => 'Endret av bruker',
  'LBL_LIST_NAME' => 'Navn',
  'LBL_EDIT_BUTTON' => 'Rediger',
  'LBL_REMOVE' => 'Fjern',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Endret av Navn',
  'LBL_TEAM' => 'Team',
  'LBL_TEAMS' => 'Team',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_LIST_FORM_TITLE' => 'Resumen Liste',
  'LBL_MODULE_NAME' => 'Resumen',
  'LBL_MODULE_TITLE' => 'Resumen',
  'LBL_MODULE_NAME_SINGULAR' => 'Resumen',
  'LBL_HOMEPAGE_TITLE' => 'Min Resumen',
  'LNK_NEW_RECORD' => 'Opprett Resumen',
  'LNK_LIST' => 'Vis Resumen',
  'LNK_IMPORT_TCT02_RESUMEN' => 'Importar Resumen',
  'LBL_SEARCH_FORM_TITLE' => 'Søk Resumen',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historie',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktivitetstrøm',
  'LBL_TCT02_RESUMEN_SUBPANEL_TITLE' => 'Resumen',
  'LBL_NEW_FORM_TITLE' => 'Ny Resumen',
  'LNK_IMPORT_VCARD' => 'Importar Resumen vCard',
  'LBL_IMPORT' => 'Importar Resumen',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Resumen record by importing a vCard from your file system.',
  'LBL_ID_PERSONA' => 'Id Persona',
  'LBL_LEASING_FECHA_PAGO' => 'Leasing Fecha pago',
  'LBL_LEASING_ANEXOS_ACTIVOS' => 'Leasing Anexos activos',
  'LBL_LEASING_ANEXOS_HISTORICOS' => 'Leasing Anexos históricos',
  'LBL_FACTORING_FECHA_PAGO' => 'Factoring Fecha pago',
  'LBL_FACTORING_ANEXOS_ACTIVOS' => 'Factoring Anexos activos',
  'LBL_FACTORING_ANEXOS_HISTORICOS' => 'Factoring Anexos históricos',
  'LBL_CAUTO_FECHA_PAGO' => 'C.Auto Fecha pago',
  'LBL_CAUTO_ANEXOS_ACTIVOS' => 'C.Auto Anexos activos',
  'LBL_CAUTO_ANEXOS_HISTORICOS' => 'C.Auto Anexos históricos',
);
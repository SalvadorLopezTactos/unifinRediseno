<?php
// created: 2017-12-22 09:54:57
$dictionary["Account"]["fields"]["tct1_p_fideicomiso_accounts"] = array (
  'name' => 'tct1_p_fideicomiso_accounts',
  'type' => 'link',
  'relationship' => 'tct1_p_fideicomiso_accounts',
  'source' => 'non-db',
  'module' => 'TCT1_P_Fideicomiso',
  'bean_name' => false,
  'vname' => 'LBL_TCT1_P_FIDEICOMISO_ACCOUNTS_FROM_TCT1_P_FIDEICOMISO_TITLE',
  'id_name' => 'tct1_p_fideicomiso_accountstct1_p_fideicomiso_ida',
);

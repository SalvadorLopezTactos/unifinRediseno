<?php
// created: 2017-12-22 09:54:57
$dictionary["TCT1_P_Fideicomiso"]["fields"]["tct1_p_fideicomiso_accounts"] = array (
  'name' => 'tct1_p_fideicomiso_accounts',
  'type' => 'link',
  'relationship' => 'tct1_p_fideicomiso_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_TCT1_P_FIDEICOMISO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'tct1_p_fideicomiso_accountsaccounts_idb',
);

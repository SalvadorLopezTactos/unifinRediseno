<?php
// created: 2017-12-22 08:34:42
$viewdefs['TCT1_P_Fideicomiso']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TCT1_P_FIDEICOMISO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'tct1_p_fideicomiso_accounts',
  ),
);

$viewdefs['TCT1_P_Fideicomiso']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TCT1_P_FIDEICOMISO_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'tct1_p_fideicomiso_accounts',
  ),
);
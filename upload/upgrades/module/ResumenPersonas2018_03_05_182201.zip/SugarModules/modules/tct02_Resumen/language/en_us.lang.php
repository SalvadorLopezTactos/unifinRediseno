<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favorite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_LIST_FORM_TITLE' => 'Resumen List',
  'LBL_MODULE_NAME' => 'Resumen',
  'LBL_MODULE_TITLE' => 'Resumen',
  'LBL_MODULE_NAME_SINGULAR' => 'Resumen',
  'LBL_HOMEPAGE_TITLE' => 'My Resumen',
  'LNK_NEW_RECORD' => 'Create Resumen',
  'LNK_LIST' => 'View Resumen',
  'LNK_IMPORT_TCT02_RESUMEN' => 'Importar Resumen',
  'LBL_SEARCH_FORM_TITLE' => 'Search Resumen',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activity Stream',
  'LBL_TCT02_RESUMEN_SUBPANEL_TITLE' => 'Resumen',
  'LBL_NEW_FORM_TITLE' => 'New Resumen',
  'LNK_IMPORT_VCARD' => 'Importar Resumen vCard',
  'LBL_IMPORT' => 'Importar Resumen',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Resumen record by importing a vCard from your file system.',
  'LBL_ID_PERSONA' => 'Id Persona',
  'LBL_LEASING_FECHA_PAGO' => 'Leasing Fecha pago',
  'LBL_LEASING_ANEXOS_ACTIVOS' => 'Leasing Anexos activos',
  'LBL_LEASING_ANEXOS_HISTORICOS' => 'Leasing Anexos históricos',
  'LBL_FACTORING_FECHA_PAGO' => 'Factoring Fecha pago',
  'LBL_FACTORING_ANEXOS_ACTIVOS' => 'Factoring Anexos activos',
  'LBL_FACTORING_ANEXOS_HISTORICOS' => 'Factoring Anexos históricos',
  'LBL_CAUTO_FECHA_PAGO' => 'C.Auto Fecha pago',
  'LBL_CAUTO_ANEXOS_ACTIVOS' => 'C.Auto Anexos activos',
  'LBL_CAUTO_ANEXOS_HISTORICOS' => 'C.Auto Anexos históricos',
);
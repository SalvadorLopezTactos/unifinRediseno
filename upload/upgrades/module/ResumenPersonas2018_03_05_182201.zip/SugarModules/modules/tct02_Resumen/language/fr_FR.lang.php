<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'ID utilisateur assigné',
  'LBL_ASSIGNED_TO_NAME' => 'Assigné à',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date de création',
  'LBL_DATE_MODIFIED' => 'Date de modification',
  'LBL_MODIFIED' => 'Modifié par',
  'LBL_MODIFIED_ID' => 'Modifié par (ID)',
  'LBL_MODIFIED_NAME' => 'Modifié par Nom',
  'LBL_CREATED' => 'Créé par',
  'LBL_CREATED_ID' => 'Créé par (ID)',
  'LBL_DOC_OWNER' => 'Propriétaire du document',
  'LBL_USER_FAVORITES' => 'Favoris pour les utilisateurs suivants',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Supprimé',
  'LBL_NAME' => 'Nom',
  'LBL_CREATED_USER' => 'Créé par',
  'LBL_MODIFIED_USER' => 'Modifié par',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_EDIT_BUTTON' => 'Éditer',
  'LBL_REMOVE' => 'Supprimer',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modifié par Nom',
  'LBL_TEAM' => 'Équipes',
  'LBL_TEAMS' => 'Équipes',
  'LBL_TEAM_ID' => 'Équipe (ID)',
  'LBL_LIST_FORM_TITLE' => 'Resumen Catalogue',
  'LBL_MODULE_NAME' => 'Resumen',
  'LBL_MODULE_TITLE' => 'Resumen',
  'LBL_MODULE_NAME_SINGULAR' => 'Resumen',
  'LBL_HOMEPAGE_TITLE' => 'Mes Resumen',
  'LNK_NEW_RECORD' => 'Créer Resumen',
  'LNK_LIST' => 'Afficher Resumen',
  'LNK_IMPORT_TCT02_RESUMEN' => 'Importar Resumen',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Resumen',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Historique',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activités',
  'LBL_TCT02_RESUMEN_SUBPANEL_TITLE' => 'Resumen',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Resumen',
  'LNK_IMPORT_VCARD' => 'Importar Resumen vCard',
  'LBL_IMPORT' => 'Importar Resumen',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Resumen record by importing a vCard from your file system.',
  'LBL_ID_PERSONA' => 'Id Persona',
  'LBL_LEASING_FECHA_PAGO' => 'Leasing Fecha pago',
  'LBL_LEASING_ANEXOS_ACTIVOS' => 'Leasing Anexos activos',
  'LBL_LEASING_ANEXOS_HISTORICOS' => 'Leasing Anexos históricos',
  'LBL_FACTORING_FECHA_PAGO' => 'Factoring Fecha pago',
  'LBL_FACTORING_ANEXOS_ACTIVOS' => 'Factoring Anexos activos',
  'LBL_FACTORING_ANEXOS_HISTORICOS' => 'Factoring Anexos históricos',
  'LBL_CAUTO_FECHA_PAGO' => 'C.Auto Fecha pago',
  'LBL_CAUTO_ANEXOS_ACTIVOS' => 'C.Auto Anexos activos',
  'LBL_CAUTO_ANEXOS_HISTORICOS' => 'C.Auto Anexos históricos',
);
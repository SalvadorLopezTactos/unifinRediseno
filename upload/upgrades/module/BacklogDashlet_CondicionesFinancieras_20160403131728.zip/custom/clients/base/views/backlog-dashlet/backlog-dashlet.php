<?php
/**
 * Created by Levementum.
 * User: jgarcia@levementum.com
 * Date: 2/25/2016
 * Time: 1:22 PM
 */

$viewdefs['base']['view']['backlog-dashlet'] = array(
    'dashlets' => array(
        array(
            'label' => 'Backlog',
            'description' => 'Backlog',
            'config' => array(),
            'preview' => array(),
        ),
    ),
//    'panels' => array(
//        array(
//            'fields' => array(
//                array(
//                    'name' => 'assigned_user_id',
//                    'label' => 'Promotor',
//                    'type' => 'relate',
//                    'view' => 'edit',
//                ),
//            ),
//        ),
//    ),
);
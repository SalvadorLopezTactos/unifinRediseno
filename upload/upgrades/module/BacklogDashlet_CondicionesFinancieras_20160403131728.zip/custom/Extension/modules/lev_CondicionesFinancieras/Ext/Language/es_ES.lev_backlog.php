<?php
$mod_strings['LBL_PORCENTAGE_MAYOR_RANGO'] = 'El Valor esta Fuera de Rango no puede ser mas de 99.99';
$mod_strings['LBL_PORCENTAGE_MENOR_RANGO'] = 'El Valor esta Fuera de Rango no puede ser menos de 1';
$mod_strings['LBL_PORCENTAGE_MAYOR_A_MAXIMO'] = 'Valor mayor a su maximo';
$mod_strings['LBL_PORCENTAGE_MENOR_MINIMO'] = 'Valor menor a su minimo';

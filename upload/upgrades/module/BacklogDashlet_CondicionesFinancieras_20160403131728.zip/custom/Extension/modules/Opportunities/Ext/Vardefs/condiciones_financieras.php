<?php
/**
 * Created by Levementum.
 * User: jgarcia@levementum.com
 * Date: 3/8/2016
 * Time: 5:25 PM
 */

$dictionary['Opportunity']['fields']['condiciones_financieras'] = array (
    'name' => 'condiciones_financieras',
    'id_name' => 'condiciones_financieras',
    'type' => 'condiciones_financieras',
    'module' => 'lev_CondicionesFinancieras',
    'source' => 'non-db',
    'dbType' => 'non-db',
    'studio' => 'visible',
    'label' => 'LBL_CONDICIONES_FINANCIERAS'
);
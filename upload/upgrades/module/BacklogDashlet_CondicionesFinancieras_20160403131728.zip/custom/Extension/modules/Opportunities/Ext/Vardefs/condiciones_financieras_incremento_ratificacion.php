<?php
/**
 * Created by Levementum.
 * User: jgarcia@levementum.com
 * Date: 3/30/2016
 * Time: 9:46 AM
 */

$dictionary['Opportunity']['fields']['condiciones_financieras_incremento_ratificacion'] = array (
    'name' => 'condiciones_financieras_incremento_ratificacion',
    'id_name' => 'condiciones_financieras_incremento_ratificacion',
    'type' => 'condiciones_financieras_incremento_ratificacion',
    'module' => 'lev_CondicionesFinancieras',
    'source' => 'non-db',
    'dbType' => 'non-db',
    'studio' => 'visible',
    'label' => 'LBL_CONDICIONES_FINANCIERAS_INCREMENTO_RATIFICACION'
);
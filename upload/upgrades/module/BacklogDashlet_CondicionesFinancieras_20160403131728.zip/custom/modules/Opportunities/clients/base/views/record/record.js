({
    extendsFrom: 'RecordView',

	initialize: function (options) {
		self = this;
		this._super("initialize", [options]);
		/*
		 * @author Carlos Zaragoza Ortiz
		 * @version 1
		 * En operaciones de solicitud de crédito quitar opción de pipeline en lista de Forecast
		 * */
		 // CVV - 28/03/2016 - Se oculto el campo de forecast
		/* 
		var opciones_forecast = app.lang.getAppListStrings('forecast_list');
		var operacion = this.model.get('tipo_operacion_c');
		Object.keys(opciones_forecast).forEach(function(key){
			//console.log("CZ tipo forecast: " + key);
			if(key == "Pipeline"){
				if(operacion == 1){
					delete opciones_forecast[key];
				}
			}

		});
		this.model.fields['forecast_c'].options = opciones_forecast;
		*/
		
		this.model.addValidationTask('check_monto_c', _.bind(this._ValidateAmount, this));
        this.model.addValidationTask('ratificacion_incremento_c', _.bind(this.validaTipoRatificacion, this));
        this.model.addValidationTask('check_condiciones_financieras', _.bind(this.validaCondicionesFinancerasRI, this));

		this.model.addValidationTask('check_condicionesFinancieras', _.bind(this.condicionesFinancierasCheck, this));
		this.model.addValidationTask('check_condicionesFinancierasIncremento', _.bind(this.condicionesFinancierasIncrementoCheck, this));


		//this.model.set('contacto_relacionado_c', "test");
		//this.model.on("click:rel_relaciones_id_c", _.bind(this.readOnly_contacto_relacionado, this));

		this.$('[data-name=contacto_relacionado_c]').click(function(){
			//alert('keydown');
		})

		this.getCurrentYearMonth();

		this.model.on("change:anio_c", _.bind(this.getCurrentYearMonth, this));

	},
	_render: function() {
        this._super("_render");
		// @author Carlos Zaragoza
		// @brief Si el usuario esta ratificando una linea autorizada, se le quitan los permisos de edición sobre oportunidades.
		app.events.on("app:sync:complete", function(){
			var ac = SUGAR.App.user.getAcls();
			if((this.model.get('tipo_operacion_c')==2) && (this.model.get('tipo_de_operacion_c')=='RATIFICACION_INCREMENTO')){

				ac.Opportunities.edit = "no";
			}else{
				ac.Opportunities.edit = "yes";
			}
		});


        if(this.model.get('tipo_operacion_c')=='2'){
            this.$('div[data-name=plazo_ratificado_incremento_c]').show();
        }else{
            this.$('div[data-name=plazo_ratificado_incremento_c]').hide();
        }
        // CVV - 28/03/2016 - Se ocultan algunos campos que fueron reemplazados por el control de condiciones financieras
		this.model.on("change:ratificacion_incremento_c", _.bind(function(){
			if(this.model.get('ratificacion_incremento_c')==false){
				this.model.set('monto_ratificacion_increment_c','0.00');
                this.$('div[data-name=plazo_ratificado_incremento_c]').hide();
                this.$('div[data-name=ri_usuario_bo_c]').hide();
                //this.model.set('ri_ca_tasa_c','0.000000');
                this.model.set('ri_porcentaje_ca_c','0.000000');
                //this.model.set('ri_porcentaje_renta_inicial_c','0.000000');
                //this.model.set('ri_vrc_c','0.000000');
                //this.model.set('ri_vri_c','0.000000');
                this.model.set('monto_ratificacion_increment_c','0.00');
                this.model.set('ri_usuario_bo_c','');
                this.model.set('plazo_ratificado_incremento_c','');
			}else{
                this.$('div[data-name=plazo_ratificado_incremento_c]').show();
                this.$('div[data-name=ri_usuario_bo_c]').show();
                this.obtieneCondicionesFinancieras();
            }
		},this));

		this.model.on("change:monto_ratificacion_increment_c", _.bind(function(){
			Number.prototype.formatMoney = function(c, d, t){
				var n = this,
					c = isNaN(c = Math.abs(c)) ? 2 : c,
					d = d == undefined ? "." : d,
					t = t == undefined ? "," : t,
					s = n < 0 ? "-" : "",
					i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
					j = (j = i.length) > 3 ? j % 3 : 0;
				return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
			};
			if(this.model.get('ratificacion_incremento_c')==true && this.model.get("tipo_de_operacion_c")=="LINEA_NUEVA") {
				var tipo = "";
				var monto = 0;
				if (Number(this.model.get("monto_ratificacion_increment_c")) == 0) {
					tipo = "Ratifiaci\u00F3n";
					monto = Number(this.model.get("monto_c"));
				} else if (Number(this.model.get("monto_ratificacion_increment_c")) > 0) {
					tipo = "Incremento";
					monto = Number(this.model.get("monto_c")) + Number(this.model.get("monto_ratificacion_increment_c"));
				} else if (Number(this.model.get("monto_ratificacion_increment_c")) < 0) {
					tipo = "Decremento";
					monto = Number(this.model.get("monto_c")) + Number(this.model.get("monto_ratificacion_increment_c"));
				}
				app.alert.show("Moto Modificado", {
					level: "info",
					title: "El disponible de la linea despues de autorizar esta solicitud de " + tipo + " sera de " + monto.formatMoney(2, '.', ','),
					autoClose: false
				});
			}
		},this))

		this.model.on("change:monto_c", _.bind(function() {
			if (this.model.get('amount') == null || this.model.get('amount') == ''){
				this.model.set('amount',this.model.get('monto_c'));
			}else{
				//Si la oportunidad es de tipo Cotización/Contrato los montos deben ser iguales
				if((this.model.get('tipo_operacion_c') == 3 || this.model.get('tipo_operacion_c') == 4 ) && parseFloat(this.model.get('amount')) != parseFloat(this.model.get('monto_c'))){
					app.alert.show("Moto de colocacion", {
							level: "alert",
							title: "El monto a operar se igualara al monto de la colocación.",
							autoClose: false
						});
					this.model.set('amount',this.model.get('monto_c'));
				}else{
					if(parseFloat(this.model.get('amount')) > parseFloat(this.model.get('monto_c')) && this.model.get('tipo_operacion_c') == 1){
						/*app.alert.show("Moto a operar invalido", {
							level: "error",
							title: "El monto a operar no puede ser mayor al  monto solicitado.",
							autoClose: false
						});
						this.model.set('amount',this.model.get('monto_c'));*/
            				}	
				}					
			}
    	},this));
    	
		this.model.on("change:amount", _.bind(function() {
			if (this.model.get('monto_c') == null || this.model.get('monto_c') == ''){
				this.model.set('monto_c',this.model.get('amount'));
			}else{
				//Si la oportunidad es de tipo Cotización/Contrato los montos deben ser iguales
				if((this.model.get('tipo_operacion_c') == 3 || this.model.get('tipo_operacion_c') == 4 ) && parseFloat(this.model.get('amount')) != parseFloat(this.model.get('monto_c'))){
					app.alert.show("Moto de colocacion", {
							level: "alert",
							title: "El monto de la colocación se igualara al monto a operar",
							autoClose: false
						});
					this.model.set('monto_c',this.model.get('amount'));
				}else{
					if(parseFloat(this.model.get('amount')) > parseFloat(this.model.get('monto_c')) && this.model.get('tipo_operacion_c') == 1){
						/*app.alert.show("Moto a operar invalido", {
							level: "error",
							title: "El monto a operar no puede ser mayor al monto de la linea.",
							autoClose: false
						});
						this.model.set('amount',this.model.get('monto_c'));*/
            				}
				}
			}
    	},this));



		/*
		 * @author Carlos Zaragoza
		 * @version 1
		 * Validamos que se pueda usar el campo vacío en el forecast. Agregar opción "…" en forecast time para indicar que se cierra este mes (esta opción se selecciona en automático si la fecha de cierre está dentro del mes corriente) Si la fecha de cierre esta fuera del mes corriente calcular si es 30, 60, etc.
		 * */
		 // CVV - 28/03/2016 - El campo de fecha de cierre se elimino del layout
		/*this.model.on("change:date_closed", _.bind(function() {
			var fecha_cierre = this.model.get('date_closed');
			var fecha_actual = new Date();
			fecha_cierre  = new Date(fecha_cierre+"T12:00:00Z");
			var months;
			months = (fecha_cierre.getFullYear() - fecha_actual.getFullYear()) * 12;
			months -= fecha_actual.getMonth();
			months += fecha_cierre.getMonth();
			//console.log("Meses: " + months);

			if(months == 0 ){
				this.model.set('forecast_time_c',"");
			}
			if(months == 1){
				this.model.set('forecast_time_c',"30");
			}
			if(months == 2){
				this.model.set('forecast_time_c',"60");
			}
			if(months == 3){
				this.model.set('forecast_time_c',"90");
			}
			if(months >= 4){
				this.model.set('forecast_time_c',"90mas");
			}

		},this));  */
		if(this.model.get('tipo_operacion_c')!='3'){
			//* Quitamos los campos Vendedor y Comisión
			this.$('div[data-name=opportunities_ag_vendedores_1_name]').hide();
			this.$('div[data-name=comision_c]').hide();
		}
		//CVV - 28/03/2016 - Se ocultan los campos de activo para reemplazarlos por control de condiciones financieras
		
		/*if(this.model.get('tipo_producto_c') != '4'){
			//Muestra los campos los valores cuando es 4
			this.$('div[data-name=activo_c]').show();
			this.$('div[data-name=sub_activo_c]').show();
			this.$('div[data-name=sub_activo_2_c]').show();
			this.$('div[data-name=sub_activo_3_c]').show();
		}else{
			//Oculta los campos
			this.$('div[data-name=activo_c]').hide();
			this.$('div[data-name=sub_activo_c]').hide();
			this.$('div[data-name=sub_activo_2_c]').hide();
			this.$('div[data-name=sub_activo_3_c]').hide();
		}*/

        console.log(this.model.get('ratificacion_incremento_c'));
        if(this.model.get('ratificacion_incremento_c')==false){
            //Oculta campos para condiciones financieras
            this.$('div[data-name=plazo_ratificado_incremento_c]').hide();
            this.$('div[data-name=ri_usuario_bo_c]').hide();
        }else{
            //Prende los campos
            this.$('div[data-name=plazo_ratificado_incremento_c]').show();
            this.$('div[data-name=ri_usuario_bo_c]').show();
        }
        //llamamos a las condiciones financieras por default para ratificación.
       // this.obtieneCondicionesFinancieras();
        this.model.on("change:plazo_ratificado_incremento_c", _.bind(function(){
            //Si cambia el plazo disparamos las condiciones:
            this.obtieneCondicionesFinancieras();
        }, this));

        this.model.on("change:tipo_producto_c", _.bind(function(){
            this.obtieneCondicionesFinancieras();
            if(this.model.get('tipo_producto_c')=='3'){
                this.$("div.record-label[data-name='ri_porcentaje_renta_inicial_c']").text("Porcentaje de Enganche R/I");
                this.$("div.record-label[data-name='porcentaje_renta_inicial_c']").text("Porcentaje de Enganche");
            }else{
                this.$("div.record-label[data-name='ri_porcentaje_renta_inicial_c']").text("Porcentaje Renta Inicial R/I");
                this.$("div.record-label[data-name='porcentaje_renta_inicial_c']").text("Porcentaje Renta Inicial");
            }
        },this));

        //Actualiza las etiquetas de acuerdo al tipo de operacion Solicitud/Cotizacion
        //Si la operacion es Cotización o Contrato cambiar etiqueta de "Monto de línea" a "Monto colocación"
        if (this.model.get('tipo_operacion_c') == '3' || this.model.get('tipo_operacion_c') == '4'){
            this.$("div.record-label[data-name='monto_c']").text("Monto colocaci\u00F3n");
            this.$("div.record-label[data-name='tipo_de_operacion_c']").text("Tipo de operaci\u00F3n");
        }else{
            this.$("div.record-label[data-name='monto_c']").text("Monto de l\u00CDnea");
            this.$("div.record-label[data-name='tipo_de_operacion_c']").text("Tipo de solicitud");
        }

        if (this.model.get('tipo_operacion_c') == '1' && this.model.get('tipo_de_operacion_c') == 'RATIFICACION_INCREMENTO'){
            this.$("div.record-label[data-name='monto_c']").text("Monto del incremento");
        }
        if(this.model.get('tipo_producto_c')=='1'){
            this.$("div.record-label[data-name='ca_importe_enganche_c']").text("Renta Inicial");
        }else{
            this.$("div.record-label[data-name='ca_importe_enganche_c']").text("Enganche");

        }
        if(this.model.get('tipo_producto_c')=='4'){
            this.$("div.record-label[data-name='ri_porcentaje_ca_c']").text("Comisi\u00F3n Incremento/Ratificaci\u00F3n");
            this.$("div.record-label[data-name='plazo_c']").text("Plazo máximo en d\u00CDas");
        }else{
            this.$("div.record-label[data-name='ri_porcentaje_ca_c']").text("Comisi\u00F3n por apertura Incremento/Ratificaci\u00F3n");
            this.$("div.record-label[data-name='plazo_c']").text("Plazo en meses");

        }
        if(this.model.get('tipo_producto_c')=='3'){
            this.$("div.record-label[data-name='ri_porcentaje_renta_inicial_c']").text("% Enganche Incremento/Ratificaci\u00F3n");
            this.$("div.record-label[data-name='porcentaje_renta_inicial_c']").text("Porcentaje de Enganche");
        }else{
            this.$("div.record-label[data-name='ri_porcentaje_renta_inicial_c']").text("% Renta Inicial Incremento/Ratificaci\u00F3n");
            this.$("div.record-label[data-name='porcentaje_renta_inicial_c']").text("Porcentaje Renta Inicial");
        }
	},
		delegateButtonEvents: function () {
			this._super("delegateButtonEvents");

			this.context.on('button:expediente_button:click', this.expedienteClicked, this);
			this.context.on('button:ratificado_button:click', this.ratificadoClicked, this);
			this.context.on('button:edit_button:click', this.checkForRatificado, this);
			//this.model.on('change:monto_c', this._ValidateAmount, this);
			//this.events['blur input[name=monto_c]'] = '_ValidateAmount';
			this.context.on('button:cancela_operacion_button:click', this.cancelaOperacion, this);
			this.context.on('button:expediente_credito_button:click', this.expedienteCredito, this);
	},
	/*
	 _ValidateAmount: function (){
	 var monto = this.model.get("amount");
	 if (monto <= 0)
	 {
	 app.alert.show("Valida Monto de Operación", {
	 level: "error",
	 title: "El monto debe ser mayor a cero.",
	 autoClose: false
	 });
	 }
	 },
	 */
	expedienteClicked: function (){
		if(this.model.get('id_process_c')== '-1'){
			app.alert.show("Expediente no disponible",{
				level: "error",
				title: "Por el momento este expediente solo se encuentra disponible en UNICS",
				autoclose:false
			});
		}else{
			var Oppid = this.model.get('id');
			window.open("#bwc/index.php?entryPoint=ExpedienteVaadinOportunidad&Oppid=" + Oppid);	
		}
		
	},
	
	expedienteCredito: function (){
		if(this.model.get('id_process_c')== '-1'){
			app.alert.show("Expediente no disponible",{
				level: "error",
				title: "El analisis de esta operación solo se encuentra disponible en UNICS",
				autoclose:false
			});
		}else{
			var Oppid = this.model.get('idsolicitud_c');
			window.open("#bwc/index.php?entryPoint=ExpedienteCredito&Oppid=" + Oppid);
		}
	},


	ratificadoClicked: function (){
        if(this.model.get('tipo_operacion_c') == '1'){
            app.alert.show("Ratificación e incremento", {
                level: "error",
                title: "No puedes ratificar en una solicitud",
                autoClose: false});
        }else
            {
                if (this.model.get('tipo_operacion_c') == "2") {
                    var newOppId = '';
                    var OppParams = {
                        'monto': this.model.get("monto_c"),
                        'relatedAccount': this.model.get("account_id"),
                        'parentId': this.model.get("id"),
                    };
                    var dnbProfileUrl = app.api.buildURL("Opportunities/Ratificado", '', {}, {});
                    app.api.call("create", dnbProfileUrl, {data: OppParams}, {
                        success: _.bind(function (data) {
                            if (data != null) {
                                newOppId = data;
                                window.location.assign("#Opportunities/" + newOppId);
                            }
                        }, this)
                    });
                } else {
                    app.alert.show("Ratificación e incremento", {
                        level: "error",
                        title: "Ratificaci&oacute;n / Incremento solamente con l&iacute;nea de cr&eacute;dito autorizada.",
                        autoClose: false
                    });
                }
            }

	},

	checkForRatificado:function (){
		var OppParams = {
			'parentId': this.model.get("id"),
		};
		var dnbProfileUrl = app.api.buildURL("Opportunities/CheckForRatificados", '', {}, {});
		app.api.call("create", dnbProfileUrl, {data: OppParams}, {
			success: _.bind(function (data) {
				if(data != null){
					if(data == true){

						app.alert.show("Operaciones Ratificadas", {
							level: "error",
							title: "Ratificacion o incremento en progreso, no se puede editar.",
							autoClose: false
						});

						this.cancelClicked();
					}
				}
			}, this)
		});
	},
    _dispose: function() {
        this._super('_dispose', []);
    },

	cancelaOperacion:function (){
        if(this.model.get('estatus_c')=='K'){
            app.alert.show("Cancela Operacion", {
                level: "error",
                title: "No puedes cancelar una operaci\u00F3n cancelada",
                autoClose: false
            });
        }else {
            app.alert.show("EstatusCancelcacion",{
                level: "warning",
                title: "Se está cancelando la operaci\u00F3n, por favor espera",
                autoClose: true
            });
			// @author Carlos Zaragoza
			// @task Cancelar la operacion solamente en Sugar si no tiene ID process.
			console.log(typeof this.model.get("id_process_c"));
			console.log(this.model.get("id_process_c"));
			if(this.model.get("id_process_c")==""){
				//No tiene proceso
				//console.log("No tiene proceso, solo se cancela localmente");
				//console.log(this.model.get('estatus_c'));
                //this.model.set('estatus_c', 'K');
				//console.log(this.model.get('estatus_c'));
                //this.saveClicked();
				//cancelamos por servicio la cuenta padre
				//console.log(this.model.get('id_linea_credito_c'));
				//console.log("ID linea papa");
				var parametros = {
					'id_linea_padre' : this.model.get('id_linea_credito_c'),
					'id' : this.model.get('id'),
					'conProceso' : 0,
					'tipo_de_operacion_c' :  this.model.get('tipo_de_operacion_c'),
					'tipo_operacion_c' :  this.model.get('tipo_operacion_c'),
				};
				//console.log(parametros);
				var cancelarOperacionPadre = app.api.buildURL("CancelaRatificacion", '', {}, {});
				app.api.call("create", cancelarOperacionPadre, {data: parametros}, {
					success: _.bind(function (data) {
						if (data != null) {
							console.log("Se cancelo padre");
							window.location.reload()
						} else {
							console.log("No se cancela Padre");
						}
					}, this)
					});

			}else{

                if (this.model.get('estatus_c') != 'K') {
                    var Operacion = this;
                    var OppParams = {
                        'idSolicitud': this.model.get("idsolicitud_c"),
                        'usuarioAutenticado': app.user.get('user_name'),
                    };
                    var cancelaOperacionUrl = app.api.buildURL("cancelaOperacionBPM", '', {}, {});
                    app.api.call("create", cancelaOperacionUrl, {data: OppParams}, {
                        success: _.bind(function (data) {
                            if (data != null) {
                                if (data['estatus'] == 'error') {
                                    app.alert.show("Cancela Operacion", {
                                        level: "error",
                                        title: "Error: " + data['descripcion'],
                                        autoClose: false
                                    });
                                } else {
                                    app.alert.show("ExitoCancel", {
                                        level: 'success',
                                        title: 'Se ha cancelado la operaci\u00F3n',
                                        autoClose: true
                                    });
									// mandamos llamar el servicio para cancelar localmente:
									var parametros = {
										'id_linea_padre' : this.model.get('id_linea_credito_c'),
										'id' : this.model.get('id'),
										'conProceso' : 1,
										'tipo_de_operacion_c' :  this.model.get('tipo_de_operacion_c'),
										'tipo_operacion_c' :  this.model.get('tipo_operacion_c'),
									};
									console.log(parametros);
									var cancelarOperacionPadre = app.api.buildURL("CancelaRatificacion", '', {}, {});
									app.api.call("create", cancelarOperacionPadre, {data: parametros}, {
										success: _.bind(function (data) {
											if (data != null) {
												console.log("Se cancelo padre");
												window.location.reload()
											} else {
												console.log("No se cancela Padre");
											}
										}, this)
									});
                                    //**************************************************
									//window.location.reload()
                                    // no va Operacion.model.set('estatus_c', 'K');
                                }

                            }
                        }, this)
                    });
                } else {
                    app.alert.show("Operacion Cancelada", {
                        level: "error",
                        title: "Esta Operaci\u00F3n ya habia sido cancelada anteriormente",
                        autoClose: false
                    });
                }
            }
        }
    },
	_ValidateAmount: function (fields, errors, callback){
		if (parseFloat(this.model.get('monto_c')) <= 0)
		{
			errors['monto_c'] = errors['monto_c'] || {};
			errors['monto_c'].required = true;
		}

		if (parseFloat(this.model.get('amount')) <= 0 && this.model.get('tipo_operacion_c')=='1')
		{
			errors['amount'] = errors['amount'] || {};
			errors['amount'].required = true;
		}

		callback(null, fields, errors);
	},
    validaTipoRatificacion: function(fields, errors, callback){
    	if(this.model.get('tipo_operacion_c')=='2') {
	        /*if (this.model.get('ratificacion_incremento_c')==true){

				if (parseFloat(this.model.get('monto_ratificacion_increment_c'))==0) {
					//errores
					app.alert.show("Monto Ratificacion", {
						level: "error",
						title: "El monto de ratificacion debe ser mayor a 0.00",
						autoClose: false
					});
					errors['monto_ratificacion_increment_c'] = errors['monto_ratificacion_increment_c'] || {};
					errors['monto_ratificacion_increment_c'].required = true;

				} else {
					this.model.set('tipo_de_operacion_c', 'RATIFICACION_INCREMENTO')
				}
	        } else {
	            this.model.set('tipo_de_operacion_c', 'LINEA_NUEVA')
	        }*/
	  	}
        callback(null, fields, errors);
    },
    obtieneCondicionesFinancieras: function(){
        /*
         * Obtiene las condidionces financieras
         * */
		if(this.model.get('tipo_producto_c')=='4') {
			var OppParams = {
				'plazo_c': this.model.get('plazo_ratificado_incremento_c'),
				'tipo_producto_c': this.model.get('tipo_producto_c'),
			};
			//console.log(OppParams);
			var dnbProfileUrl = app.api.buildURL("Opportunities/CondicionesFinancieras", '', {}, {});
			app.api.call("create", dnbProfileUrl, {data: OppParams}, {
				success: _.bind(function (data) {
					if (data != null) {
						//CVV - 28/03/2016 - Se reemplaza por control de condiciones financieras
						/*
						 if(this.model.get('tipo_producto_c')=='1'){
						 this.model.set('ri_porcentaje_ca_c',data.porcentaje_ca_c);
						 this.model.set('ri_vrc_c',data.vrc_c);
						 this.model.set('ri_vri_c',data.vri_c);
						 this.model.set('ri_ca_tasa_c',data.ca_tasa_c);
						 this.model.set('ri_porcentaje_renta_inicial_c',data.porcentaje_renta_inicial_c);
						 }else if(this.model.get('tipo_producto_c')=='3'){
						 this.model.set('ri_ca_tasa_c',data.ca_tasa_c);
						 this.model.set('ri_porcentaje_ca_c',data.porcentaje_ca_c);
						 this.model.set('ri_porcentaje_renta_inicial_c',data.porcentaje_renta_inicial_c);
						 this.model.set('ri_vrc_c','0.0');
						 this.model.set('ri_vri_c','0.0');
						 }else */
						if (this.model.get('tipo_producto_c') == '4') {
							//this.model.set('ri_ca_tasa_c',data.ca_tasa_c);
							this.model.set('puntos_sobre_tasa_c', data.ca_tasa_c);
							this.model.set('ri_porcentaje_ca_c', data.porcentaje_ca_c);
							//this.model.set('ri_porcentaje_renta_inicial_c','0.0');
							//this.model.set('ri_vrc_c','0.0');
							//this.model.set('ri_vri_c','0.0');
						}

					}
				}, this)
			});
		}
    },
	validaCondicionesFinancerasRI: function(fields, errors, callback){
		if(this.model.get('ratificacion_incremento_c')==true && this.model.get('tipo_operacion_c') == '2') {
			// CVV - 28/03/2016 - Se reemplaza por control de condiciones financieras
			/*if (this.model.get('tipo_producto_c') == '1') { //Leasing
				if (Number(this.model.get('ri_ca_tasa_c')) >= 100 || Number(this.model.get('ri_ca_tasa_c') < 0) || this.model.get('ri_ca_tasa_c') == '') {
					errors['ri_ca_tasa_c'] = errors['ri_ca_tasa_c'] || {};
					errors['ri_ca_tasa_c'].required = true;
				}
				if (Number(this.model.get('ri_porcentaje_ca_c')) >= 100 || Number(this.model.get('ri_porcentaje_ca_c') < 0 || this.model.get('ri_porcentaje_ca_c') == '')) {
					errors['ri_porcentaje_ca_c'] = errors['ri_porcentaje_ca_c'] || {};
					errors['ri_porcentaje_ca_c'].required = true;
				}
				if (Number(this.model.get('ri_vrc_c')) >= 100 || Number(this.model.get('ri_vrc_c') < 0) || this.model.get('ri_vrc_c') == '') {
					errors['ri_vrc_c'] = errors['ri_vrc_c'] || {};
					errors['ri_vrc_c'].required = true;
				}
				if (Number(this.model.get('ri_porcentaje_renta_inicial_c')) >= 100 || Number(this.model.get('ri_porcentaje_renta_inicial_c') < 0) || this.model.get('ri_porcentaje_renta_inicial_c') == '') {
					errors['ri_porcentaje_renta_inicial_c'] = errors['ri_porcentaje_renta_inicial_c'] || {};
					errors['ri_porcentaje_renta_inicial_c'].required = true;
				}
				if (Number(this.model.get('ri_vri_c')) >= 100 || Number(this.model.get('ri_vri_c') < 0) || this.model.get('ri_vri_c') == '') {
					errors['ri_vri_c'] = errors['ri_vri_c'] || {};
					errors['ri_vri_c'].required = true;
				}
			}
			if (this.model.get('tipo_producto_c') == '3') { //CA
				if (Number(this.model.get('ri_ca_tasa_c')) >= 100 || Number(this.model.get('ri_ca_tasa_c') < 0) || this.model.get('ri_ca_tasa_c') == '') {
					errors['ri_ca_tasa_c'] = errors['ri_ca_tasa_c'] || {};
					errors['ri_ca_tasa_c'].required = true;
				}
				if (Number(this.model.get('ri_porcentaje_ca_c')) >= 100 || Number(this.model.get('ri_porcentaje_ca_c') < 0) || this.model.get('ri_porcentaje_ca_c') == '') {
					errors['ri_porcentaje_ca_c'] = errors['ri_porcentaje_ca_c'] || {};
					errors['ri_porcentaje_ca_c'].required = true;
				}
				if (Number(this.model.get('ri_porcentaje_renta_inicial_c')) >= 100 || Number(this.model.get('ri_porcentaje_renta_inicial_c') < 0) || this.model.get('ri_porcentaje_renta_inicial_c') == '') {
					errors['ri_porcentaje_renta_inicial_c'] = errors['ri_porcentaje_renta_inicial_c'] || {};
					errors['ri_porcentaje_renta_inicial_c'].required = true;
				}

			}*/
			if (this.model.get('tipo_producto_c') == '4') { //Factoraje
				/*if (Number(this.model.get('ri_ca_tasa_c')) >= 100 || Number(this.model.get('ri_ca_tasa_c') < 0) || this.model.get('ri_ca_tasa_c') == '') {
					errors['ri_ca_tasa_c'] = errors['ri_ca_tasa_c'] || {};
					errors['ri_ca_tasa_c'].required = true;
				}*/
				if (Number(this.model.get('ri_porcentaje_ca_c')) >= 100 || Number(this.model.get('ri_porcentaje_ca_c') < 0) || this.model.get('ri_porcentaje_ca_c') == '') {
					errors['ri_porcentaje_ca_c'] = errors['ri_porcentaje_ca_c'] || {};
					errors['ri_porcentaje_ca_c'].required = true;
				}
				if(this.model.get('ri_tipo_tasa_ordinario_c') == undefined || this.model.get('ri_tipo_tasa_ordinario_c') == ""){
					//error
					errors['ri_tipo_tasa_ordinario_c'] = errors['ri_tipo_tasa_ordinario_c'] || {};
					errors['ri_tipo_tasa_ordinario_c'].required = true;
				}
				if(this.model.get('ri_instrumento_c') == undefined || this.model.get('ri_instrumento_c') == ""){
					//error
					errors['ri_instrumento_c'] = errors['ri_instrumento_c'] || {};
					errors['ri_instrumento_c'].required = true;
				}
				if(this.model.get('ri_puntos_sobre_tasa_c') == "" || this.model.get('ri_puntos_sobre_tasa_c') == undefined || (Number(this.model.get('ri_puntos_sobre_tasa_c'))<0 || Number(this.model.get('ri_puntos_sobre_tasa_c'))>99.999999)){
					//error
					errors['ri_puntos_sobre_tasa_c'] = errors['ri_puntos_sobre_tasa_c'] || {};
					errors['ri_puntos_sobre_tasa_c'].required = true;
				}
				if(this.model.get('ri_tipo_tasa_moratorio_c') == undefined || this.model.get('ri_tipo_tasa_moratorio_c') == ""){
					//error
					errors['ri_tipo_tasa_moratorio_c'] = errors['ri_tipo_tasa_moratorio_c'] || {};
					errors['ri_tipo_tasa_moratorio_c'].required = true;
				}
				if(this.model.get('ri_instrumento_moratorio_c') == undefined || this.model.get('ri_instrumento_moratorio_c') == ""){
					//error
					errors['ri_instrumento_moratorio_c'] = errors['ri_instrumento_moratorio_c'] || {};
					errors['ri_instrumento_moratorio_c'].required = true;
				}
				if(this.model.get('ri_puntos_tasa_moratorio_c') == "" || this.model.get('ri_puntos_tasa_moratorio_c') == undefined || (Number(this.model.get('ri_puntos_tasa_moratorio_c'))<0 || Number(this.model.get('ri_puntos_tasa_moratorio_c'))>99.999999)){
					//error
					errors['ri_puntos_tasa_moratorio_c'] = errors['ri_puntos_tasa_moratorio_c'] || {};
					errors['ri_puntos_tasa_moratorio_c'].required = true;
				}
				if(this.model.get('ri_factor_moratorio_c') == "" || this.model.get('ri_factor_moratorio_c') == undefined ||     (Number(this.model.get('ri_factor_moratorio_c'))<0 || Number(this.model.get('ri_factor_moratorio_c'))>99.999999)){
					//error
					errors['ri_factor_moratorio_c'] = errors['ri_factor_moratorio_c'] || {};
					errors['ri_factor_moratorio_c'].required = true;
				}
				if(this.model.get('ri_cartera_descontar_c') == "" || this.model.get('ri_cartera_descontar_c') == undefined ){
					//error
					errors['ri_cartera_descontar_c'] = errors['ri_cartera_descontar_c'] || {};
					errors['ri_cartera_descontar_c'].required = true;
				}
				/*
				if(this.model.get('ri_tasa_fija_ordinario_c') == null || this.model.get('ri_tasa_fija_ordinario_c') == "" || (Number(this.model.get('ri_tasa_fija_ordinario_c'))<0 || Number(this.model.get('ri_tasa_fija_ordinario_c'))>99.999999)){
					//error
					errors['ri_tasa_fija_ordinario_c'] = errors['ri_tasa_fija_ordinario_c'] || {};
					errors['ri_tasa_fija_ordinario_c'].required = true;
				}
				if(this.model.get('ri_tasa_fija_moratorio_c') == null || this.model.get('ri_tasa_fija_moratorio_c') == "" || (Number(this.model.get('ri_tasa_fija_moratorio_c'))<0 || Number(this.model.get('ri_tasa_fija_moratorio_c'))>99.999999)){
					//error
					errors['ri_tasa_fija_moratorio_c'] = errors['ri_tasa_fija_moratorio_c'] || {};
					errors['ri_tasa_fija_moratorio_c'].required = true;
				}
				*/
			}
		}else{
            //this.model.set('ri_ca_tasa_c','0.000000');
            this.model.set('ri_porcentaje_ca_c','0.000000');
            //this.model.set('ri_porcentaje_renta_inicial_c','0.000000');
            //this.model.set('ri_vrc_c','0.000000');
            //this.model.set('ri_vri_c','0.000000');
            this.model.set('monto_ratificacion_increment_c','0.00');
            this.model.set('ri_usuario_bo_c','');
            this.model.set('plazo_ratificado_incremento_c','');
        }
		/*
		if(errors.length==0){
			this.model.set('tipo_de_operacion_c', 'RATIFICACION_INCREMENTO');
		}else{
			this.model.set('tipo_de_operacion_c', 'LINEA_NUEVA')
		}*/
		callback(null, fields, errors);
	},


    /*ratificado_button : function() {
        if(this.model.get('tipo_operacion_c') == '1') {
            this.hide_button('ratificado_button');
        }
    },*/
   /* hide_button: function(name) {
console.log(name);
        var button_sel = '';
        var button_index = '';
        // find the buttons index for the share button
        _.find(this.meta.buttons, function(bn, idx) {
            console.log(bn);
            if(bn.name == 'main_dropdown') {
                button_sel = idx;
                _.find(bn.buttons, function(bbn, idx_bbn) {
                    if(bbn.name == name) {
                        button_index = idx_bbn;
                        return true;
                    }
                });
                return true;
            }
        });
        if(button_sel != '' && button_index != '')
        {
            console.log(button_sel);
            console.log(button_index);
            //remove the meta
            this.meta.buttons[button_sel].buttons.splice(button_index, 1);
        }
    },*/

	getCurrentYearMonth: function(){

		var currentYear = (new Date).getFullYear();
		var currentMonth = (new Date).getMonth();
		var currentDay = (new Date).getDate();
		//currentMonth += 1;

		if(currentDay < 20){
			currentMonth += 1;
		}
		if(currentDay >= 20){
			currentMonth += 2;
		}
		var opciones_year = app.lang.getAppListStrings('anio_list');
		Object.keys(opciones_year).forEach(function(key){
			if(key < currentYear){
				delete opciones_year[key];
			}
		});
		this.model.fields['anio_c'].options = opciones_year;

		var opciones_mes = app.lang.getAppListStrings('mes_list');
		if(this.model.get("anio_c") <= currentYear){
			Object.keys(opciones_mes).forEach(function(key){
				if(key < currentMonth){
					delete opciones_mes[key];
				}
			});
		}

		this.model.fields['mes_c'].options = opciones_mes;
		this.render();
	},

	condicionesFinancierasCheck: function(fields, errors, callback){

		if(this.model.get("tipo_operacion_c") == 1) {
			if (_.isEmpty(this.model.get('condiciones_financieras'))) {
				errors[$(".addCondicionFinanciera")] = errors['condiciones_financieras'] || {};
				errors[$(".addCondicionFinanciera")].required = true;

				$('.condiciones_financieras').css('border-color', 'red');
				app.alert.show("CondicionFinanciera requerida", {
					level: "error",
					title: "Al menos una Condicion Financiera es requerida.",
					autoClose: false
				});
			}
		}
		callback(null, fields, errors);
	},

	condicionesFinancierasIncrementoCheck: function(fields, errors, callback){

		if(this.model.get("ratificacion_incremento_c") == 1) {
			if (_.isEmpty(this.model.get('condiciones_financieras_incremento_ratificacion'))) {
				errors[$(".add_incremento_CondicionFinanciera")] = errors['condiciones_financieras_incremento_ratificacion'] || {};
				errors[$(".add_incremento_CondicionFinanciera")].required = true;

				$('.condiciones_financieras_incremento_ratificacion').css('border-color', 'red');
				app.alert.show("CondicionFinanciera requerida", {
					level: "error",
					title: "Al menos una Condicion Financiera de Incremento/Ratificacion es requerida.",
					autoClose: false
				});
			}
		}
		callback(null, fields, errors);
	},
})



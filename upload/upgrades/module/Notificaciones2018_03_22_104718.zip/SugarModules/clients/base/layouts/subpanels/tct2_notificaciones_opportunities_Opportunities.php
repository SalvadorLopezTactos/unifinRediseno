<?php
// created: 2018-03-22 10:47:18
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TCT2_NOTIFICACIONES_OPPORTUNITIES_FROM_TCT2_NOTIFICACIONES_TITLE',
  'context' => 
  array (
    'link' => 'tct2_notificaciones_opportunities',
  ),
);
<?php
// created: 2018-03-22 10:47:18
$dictionary["User"]["fields"]["tct2_notificaciones_users"] = array (
  'name' => 'tct2_notificaciones_users',
  'type' => 'link',
  'relationship' => 'tct2_notificaciones_users',
  'source' => 'non-db',
  'module' => 'TCT2_Notificaciones',
  'bean_name' => false,
  'vname' => 'LBL_TCT2_NOTIFICACIONES_USERS_FROM_USERS_TITLE',
  'id_name' => 'tct2_notificaciones_usersusers_ida',
  'link-type' => 'many',
  'side' => 'left',
);

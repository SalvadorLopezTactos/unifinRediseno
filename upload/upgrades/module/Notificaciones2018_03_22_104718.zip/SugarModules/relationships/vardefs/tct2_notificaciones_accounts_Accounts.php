<?php
// created: 2018-03-22 10:47:18
$dictionary["Account"]["fields"]["tct2_notificaciones_accounts"] = array (
  'name' => 'tct2_notificaciones_accounts',
  'type' => 'link',
  'relationship' => 'tct2_notificaciones_accounts',
  'source' => 'non-db',
  'module' => 'TCT2_Notificaciones',
  'bean_name' => false,
  'vname' => 'LBL_TCT2_NOTIFICACIONES_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'tct2_notificaciones_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);

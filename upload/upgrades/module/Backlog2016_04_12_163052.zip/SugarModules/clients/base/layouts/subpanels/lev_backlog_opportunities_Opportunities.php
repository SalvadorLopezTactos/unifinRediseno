<?php
// created: 2016-02-29 17:42:46
$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);

$viewdefs['Opportunities']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_LEV_BACKLOG_TITLE',
  'context' => 
  array (
    'link' => 'lev_backlog_opportunities',
  ),
);
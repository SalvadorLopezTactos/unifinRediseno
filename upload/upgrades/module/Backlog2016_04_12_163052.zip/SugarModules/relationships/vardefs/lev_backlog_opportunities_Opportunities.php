<?php
// created: 2016-04-12 16:30:52
$dictionary["Opportunity"]["fields"]["lev_backlog_opportunities"] = array (
  'name' => 'lev_backlog_opportunities',
  'type' => 'link',
  'relationship' => 'lev_backlog_opportunities',
  'source' => 'non-db',
  'module' => 'lev_Backlog',
  'bean_name' => 'lev_Backlog',
  'vname' => 'LBL_LEV_BACKLOG_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'lev_backlog_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);

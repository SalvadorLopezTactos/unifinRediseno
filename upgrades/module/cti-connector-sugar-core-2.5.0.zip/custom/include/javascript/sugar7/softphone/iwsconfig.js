log.setLogLevel(enumloglevel.debug);
var SoftPhone_PureCloudEnvironment = "mypurecloud.com";
var SoftPhone_WebAppUrl = window.location.origin + "/custom/include/ixnmgr.html";
var pefParams = {
    customInteractionAttributes: ["context.email", "sugar_id", "contact_id"],
    settings: {
        sso: false,
        hideWebRTCPopUpOption: false,
        enableCallLogs: true,
        hideCallLogSubject: false,
        hideCallLogContact: false,
        hideCallLogRelation: false,
        dedicatedLoginWindow: false,
        embeddedInteractionWindow: true,
        enableConfigurableCallerId: false,
        enableServerSideLogging: false,
        enableCallHistory: true,
        theme: {
            primary: "#HHH",
            text: "#FFF"
        }
    },
    clientIds: {
        "mypurecloud.com": "a8fb84d4-4311-4bb1-abe4-2d8220d92b63",
        "mypurecloud.de": "0191dcb8-7736-4453-9519-fa6ff3132795",
        "mypurecloud.ie": "b8547e1c-8932-4391-a4ba-e35564fa70a9"
    },
    helpLinks: {}
};
var config = {
    context: window,
    layoutType: "smart-ui-widget",
    integrationType: "pure-embeddable",
    url: "https://apps." + SoftPhone_PureCloudEnvironment + "/crm/softphoneSugarCRM/index.html?request_configuration=true&full_PEF=true&crm_domain=" + window.location.origin,
    auth: {
        environment: SoftPhone_PureCloudEnvironment,
        notReadyPresenceId: "227b37e2-f1d0-4dd0-8f50-badd7cf6d158",
        onQueuePresenceId: "e08eaf1b-ee47-4fa9-a231-1200e284798f"
    },
    pefParams: pefParams,
    smartUi: {
        mainJSpath: "custom/include/javascript/sugar7/softphone/softphone-connector-smart-ui.min.js",
        appendToElement: "IWSConnectorToolbar",
        showConnectionLed: true,
        visibleView: {},
        globalViews: [],
        widget: {
            logo: "cloud",
            background: "#fff"
        },
    }
};
$(document).ready(function () {
    iwscore.initCTI(config);
    iwscore.enableCTI();
    window['isToolBarLoaded'] = true;
});
/*
iwscore.initCTI({
    context: window, placeHolder: "IWSConnectorToolbar",
    integrationType: "wde"
});
//iwscore.enableCTI();
window.isToolBarLoaded = true;
iwscore.initIWSToolBar('#FrameIWSConnector', '#IWSConnectorToolbar', 'custom/include/images', "softphon_");
iwscore.showIWSToolBar(true, true, true);
iwscore.createConnection('localhost', '6969', {'protocol':'wss'});
*/

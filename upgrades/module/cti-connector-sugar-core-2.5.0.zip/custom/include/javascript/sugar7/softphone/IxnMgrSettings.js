var SoftPhone_WebAppUrl = "http://genesys:8025/webixnmgr/ixn";
var SoftPhone_PureCloudEnvironment = "mypurecloud.com";

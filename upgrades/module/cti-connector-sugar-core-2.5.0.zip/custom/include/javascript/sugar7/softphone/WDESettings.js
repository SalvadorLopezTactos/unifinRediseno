var SoftPhone_WebAppUrl = "http://genesys:8025/webixnmgr/";
var SoftPhone_WDEServerAddress = "localhost";
var SoftPhone_WDEServerPort = "6969";

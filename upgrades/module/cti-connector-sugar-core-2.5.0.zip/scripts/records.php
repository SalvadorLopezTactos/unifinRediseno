<?php
/**
 * Copyright 2016 SugarCRM Inc.  Licensed by SugarCRM under the Apache 2.0 license.
 */
 echo "start...";
if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');


require_once('include/SugarQuery/SugarQuery.php');
require_once('include/upload_file.php');
$sugarQuery = new SugarQuery();

//fetch the bean of the module to query
$bean = BeanFactory::newBean('Soft_WDEScript');


//create first query
$sql = new SugarQuery();
$sql->select('id');
$sql->from($bean);
$sql->Where()->equals('name', 'util.js');

$result = $sql->execute();

$count = count($result);

if ($count == 0)
{
	echo "No WDEScripts records found";
	createWDEScriptFile('util.js', 'custom/include/javascript/sugar7/softphone/util.js');
	createWDEScriptFile('iwscript.js', 'custom/include/javascript/sugar7/softphone/iwscript.js'); 
	createWDEScriptFile('iwsconfig.js', 'custom/include/javascript/sugar7/softphone/iwsconfig.js');    
	//createWDEScriptFile('SDK.js', 'custom/include/javascript/sugar7/softphone/SDK.js');  

}
else
{
	echo "WDEScripts records already found";
}


function createWDEScriptFile($name, $path) {
	echo 'createWDEScriptFile : $path\n';
	
    $uploadFile = new UploadFile();

	//get the file location
	$uploadFile->temp_file_location = $path;
	echo '$uploadFile->temp_file_location\n';
	$file = $uploadFile->get_file_contents();	

	echo '$file\n';

	$beanNew = BeanFactory::newBean('Soft_WDEScript');
	
	$beanNew->name = $name;
	$beanNew->scriptcontent = $file;

	//Save
	$beanNew->save();
}



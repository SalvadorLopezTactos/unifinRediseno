<?php

//RHF

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

set_time_limit(300);

$server_software = $_SERVER["SERVER_SOFTWARE"];
if (strpos($server_software, 'Microsoft-IIS') !== true) {
    require("modules/Administration/UpgradeAccess.php");
}
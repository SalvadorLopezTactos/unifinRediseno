<?php
// created: 2022-04-27 14:56:21
$dictionary["dir_Sepomex"]["fields"]["dir_sepomex_dire_direccion"] = array (
  'name' => 'dir_sepomex_dire_direccion',
  'type' => 'link',
  'relationship' => 'dir_sepomex_dire_direccion',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIR_SEPOMEX_DIRE_DIRECCION_FROM_DIR_SEPOMEX_TITLE',
  'id_name' => 'dir_sepomex_dire_direcciondir_sepomex_ida',
  'link-type' => 'many',
  'side' => 'left',
);

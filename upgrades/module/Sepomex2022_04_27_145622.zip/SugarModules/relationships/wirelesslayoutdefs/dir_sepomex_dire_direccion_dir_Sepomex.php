<?php
 // created: 2022-04-27 14:56:22
$layout_defs["dir_Sepomex"]["subpanel_setup"]['dir_sepomex_dire_direccion'] = array (
  'order' => 100,
  'module' => 'dire_Direccion',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIR_SEPOMEX_DIRE_DIRECCION_FROM_DIRE_DIRECCION_TITLE',
  'get_subpanel_data' => 'dir_sepomex_dire_direccion',
);

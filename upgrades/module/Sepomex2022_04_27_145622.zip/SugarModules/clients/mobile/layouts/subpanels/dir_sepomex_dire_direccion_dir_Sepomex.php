<?php
// created: 2022-04-27 14:56:22
$viewdefs['dir_Sepomex']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIR_SEPOMEX_DIRE_DIRECCION_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dir_sepomex_dire_direccion',
  ),
);
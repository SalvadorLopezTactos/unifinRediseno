<?php
// created: 2022-04-22 12:44:59
$viewdefs['QPRO_Gestion_Encuestas']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_QPRO_GESTION_ENCUESTAS_QPRO_ENCUESTAS_FROM_QPRO_ENCUESTAS_TITLE',
  'context' => 
  array (
    'link' => 'qpro_gestion_encuestas_qpro_encuestas',
  ),
);
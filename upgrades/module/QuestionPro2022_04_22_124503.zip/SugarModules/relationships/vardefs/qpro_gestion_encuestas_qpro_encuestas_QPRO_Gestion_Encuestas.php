<?php
// created: 2022-04-22 12:45:02
$dictionary["QPRO_Gestion_Encuestas"]["fields"]["qpro_gestion_encuestas_qpro_encuestas"] = array (
  'name' => 'qpro_gestion_encuestas_qpro_encuestas',
  'type' => 'link',
  'relationship' => 'qpro_gestion_encuestas_qpro_encuestas',
  'source' => 'non-db',
  'module' => 'QPRO_Encuestas',
  'bean_name' => false,
  'vname' => 'LBL_QPRO_GESTION_ENCUESTAS_QPRO_ENCUESTAS_FROM_QPRO_GESTION_ENCUESTAS_TITLE',
  'id_name' => 'qpro_gestion_encuestas_qpro_encuestasqpro_gestion_encuestas_ida',
  'link-type' => 'many',
  'side' => 'left',
);

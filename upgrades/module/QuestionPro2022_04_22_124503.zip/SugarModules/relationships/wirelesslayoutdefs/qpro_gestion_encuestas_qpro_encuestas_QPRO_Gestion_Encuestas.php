<?php
 // created: 2022-04-22 12:45:03
$layout_defs["QPRO_Gestion_Encuestas"]["subpanel_setup"]['qpro_gestion_encuestas_qpro_encuestas'] = array (
  'order' => 100,
  'module' => 'QPRO_Encuestas',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_QPRO_GESTION_ENCUESTAS_QPRO_ENCUESTAS_FROM_QPRO_ENCUESTAS_TITLE',
  'get_subpanel_data' => 'qpro_gestion_encuestas_qpro_encuestas',
);

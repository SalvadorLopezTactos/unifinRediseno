<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equip',
  'LBL_TEAMS' => 'Equips',
  'LBL_TEAM_ID' => 'ID de l&#39;equip',
  'LBL_ASSIGNED_TO_ID' => 'ID d&#39;usuari assignat',
  'LBL_ASSIGNED_TO_NAME' => 'Assignat a',
  'LBL_TAGS_LINK' => 'Etiquetes',
  'LBL_TAGS' => 'Etiquetes',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data de creació',
  'LBL_DATE_MODIFIED' => 'Última Modificació',
  'LBL_MODIFIED' => 'Modificat per',
  'LBL_MODIFIED_ID' => 'Modificat per ID',
  'LBL_MODIFIED_NAME' => 'Modificat Per Nom',
  'LBL_CREATED' => 'Creat Per',
  'LBL_CREATED_ID' => 'Creat per ID',
  'LBL_DOC_OWNER' => 'Propietari del document',
  'LBL_USER_FAVORITES' => 'Usuaris que son favorits',
  'LBL_DESCRIPTION' => 'Descripció',
  'LBL_DELETED' => 'Suprimit',
  'LBL_NAME' => 'Nom',
  'LBL_CREATED_USER' => 'Creat Per Usuari',
  'LBL_MODIFIED_USER' => 'Modificat Per Usuari',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_EDIT_BUTTON' => 'Edita',
  'LBL_REMOVE' => 'Suprimir',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificat per nom',
  'LBL_EXPORT_CREATED_BY_NAME' => 'Creat pel nom',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Gestión de Encuestas Llista',
  'LBL_MODULE_NAME' => 'Gestión de Encuestas',
  'LBL_MODULE_TITLE' => 'Gestión de Encuestas',
  'LBL_MODULE_NAME_SINGULAR' => 'Gestión de Encuesta',
  'LBL_HOMEPAGE_TITLE' => 'Meu Gestión de Encuestas',
  'LNK_NEW_RECORD' => 'Crea Gestión de Encuesta',
  'LNK_LIST' => 'Vista Gestión de Encuestas',
  'LNK_IMPORT_QPRO_GESTION_ENCUESTAS' => 'Importar Gestión de Encuestas',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Gestión de Encuesta',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Veure historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Seqüència d&#39;activitats',
  'LBL_QPRO_GESTION_ENCUESTAS_SUBPANEL_TITLE' => 'Gestión de Encuestas',
  'LBL_NEW_FORM_TITLE' => 'Nou Gestión de Encuesta',
  'LNK_IMPORT_VCARD' => 'Importar Gestión de Encuesta vCard',
  'LBL_IMPORT' => 'Importar Gestión de Encuestas',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Gestión de Encuesta record by importing a vCard from your file system.',
  'LBL_QPRO_GESTION_ENCUESTAS_FOCUS_DRAWER_DASHBOARD' => 'Gestión de Encuestas Panel de Enfoque',
  'LBL_QPRO_GESTION_ENCUESTAS_RECORD_DASHBOARD' => 'Gestión de Encuestas Tablero de Registro',
  'LBL_TIPO' => 'Tipo',
  'LBL_ENCUESTA_ID' => 'Id Encuesta',
  'LBL_TEMPLATE_ID' => 'Id Plantilla',
  'LBL_URL' => 'URL',
  'LBL_ESTATUS' => 'Estatus',
  'LBL_TIPO_ENVIO' => 'Tipo de envío',
  'LBL_FECHA_EXPIRACION' => 'Fecha de expiración',
  'LBL_PLANTILLA' => 'Plantilla HTML',
);
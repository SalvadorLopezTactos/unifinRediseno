<?php
// created: 2022-06-15 20:25:16
$viewdefs['S_seguros']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_COT_COTIZACIONES_S_SEGUROS_FROM_COT_COTIZACIONES_TITLE',
  'context' => 
  array (
    'link' => 'cot_cotizaciones_s_seguros',
  ),
);
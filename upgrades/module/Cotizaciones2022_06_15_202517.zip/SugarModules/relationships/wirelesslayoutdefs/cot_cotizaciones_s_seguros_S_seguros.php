<?php
 // created: 2022-06-15 20:25:17
$layout_defs["S_seguros"]["subpanel_setup"]['cot_cotizaciones_s_seguros'] = array (
  'order' => 100,
  'module' => 'Cot_Cotizaciones',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_COT_COTIZACIONES_S_SEGUROS_FROM_COT_COTIZACIONES_TITLE',
  'get_subpanel_data' => 'cot_cotizaciones_s_seguros',
);

<?php
// created: 2022-06-15 20:25:16
$dictionary["S_seguros"]["fields"]["cot_cotizaciones_s_seguros"] = array (
  'name' => 'cot_cotizaciones_s_seguros',
  'type' => 'link',
  'relationship' => 'cot_cotizaciones_s_seguros',
  'source' => 'non-db',
  'module' => 'Cot_Cotizaciones',
  'bean_name' => false,
  'vname' => 'LBL_COT_COTIZACIONES_S_SEGUROS_FROM_S_SEGUROS_TITLE',
  'id_name' => 'cot_cotizaciones_s_seguross_seguros_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
	$mod_strings['LBL_ADD_IWS'] = 'View Interaction Detail';
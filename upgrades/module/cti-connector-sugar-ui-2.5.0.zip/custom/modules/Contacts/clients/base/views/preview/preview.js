({

extendsFrom: 'PreviewView',

initialize: function(options) {
    this._super('initialize', [options]);
},

_renderHtml: function(ctx, options){
	this._super('_renderHtml', [ctx, options]);
	console.log("PreviewView _renderHtml called");

	

	var userAcl = SUGAR.App.user.getAcls()["Soft_WDEScript"];
	if (!userAcl || (userAcl["access"] && userAcl["access"] == "no") || (userAcl["view"] && userAcl["view"] == "no"))
	{
	    console.warn("User doesnt'have the WDE Script persmissions to load WDE Personalization.");
	    return;
	} 

    try
	{
		var phones = this.$el.find("div[data-type|='phone']");
			
	    console.log("_renderHtml phones Mimmo version 1.1:" + phones.length);		
								
		for (var i = 0; i < phones.length; i++)
		{
			var el = $(phones[i]).find(".ellipsis_inline");
			if (el && el.length == 1)
			{
				var phone = $(el).html().trim();
				if (phone && phone.indexOf("<a") == -1)
				{
					var link = $("<a></a>");
					link.html(phone);
					link.click(function(){
						console.log("link click!");
						var phoneNumber = $(this).html().trim();
						MakeCall(phoneNumber);
					});
					el.empty();
					el.append(link);
				}
			} 
		}
			
		$(phones).bind("DOMSubtreeModified", function() {
			console.log("_phoneFieldMofied called")
			var el = $(this).find(".ellipsis_inline");
			if (el && el.length == 1)
			{
				var phone = $(el).html().trim();
				console.log(phone);
				if (phone && phone.indexOf("<a") == -1)
				{
					var link = $("<a></a>");
					link.html(phone);
					link.click(function(){
						var phoneNumber = $(this).html().trim();
						MakeCall(phoneNumber);
					});
					el.empty();
					el.append(link);
				}
			}
		});			
	}catch(e)
	{
		console.log("_renderHtml error - " + e.message);
	}
		
 }

})
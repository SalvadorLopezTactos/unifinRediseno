<?php
/**
 * Copyright 2016 SugarCRM Inc.  Licensed by SugarCRM under the Apache 2.0 license.
 */
if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');

$fieldsByModule = array(
    'Tasks' => array(
        'iws_interactionid_c',
        'iws_medianame_c',
    ),
    'Calls' => array(
        'iws_interactionid_c',
        'iws_medianame_c',
    ),
);

require_once('modules/DynamicFields/DynamicField.php');

foreach ($fieldsByModule as $moduleName => $fields) {
    foreach($fields as $field){
        $dyField = new DynamicField();
        $dyField->bean = BeanFactory::getBean($moduleName);;
        $dyField->module = $moduleName;
        $dyField->deleteField($field);
    }
}

echo "Sto stampando da dentro lo script di pulizia1";

require_once("modules/Administration/QuickRepairAndRebuild.php");
$randc = new RepairAndClear();
//Rebuild extensions then clear include/javascript files
$randc->repairAndClearAll(array('rebuildExtensions', 'clearAdditionalCaches'),array(translate('LBL_ALL_MODULES')), false, true);

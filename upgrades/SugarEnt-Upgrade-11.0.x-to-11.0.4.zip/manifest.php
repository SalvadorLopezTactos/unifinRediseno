<?php
// created: 2022-08-01 11:21:17
$manifest = array(
    'acceptable_sugar_flavors' => array('ENT'),
    'acceptable_sugar_versions' =>
        array(
            'exact_matches' => array('11.0.0.0','11.0.1.0','11.0.2.0','11.0.3.0'),
            'regex_matches' => array()
        ),
    'author' => 'SugarCRM, Inc.',
    'copy_files' =>
        array(
            'from_dir' => 'SugarEnt-Upgrade-11.0.x-to-11.0.4',
            'to_dir' => '',
            'force_copy' => array()
        ),
    'description' => '',
    'icon' => '',
    'is_uninstallable' => false,
    'offline_client_applicable' => true,
    'name' => 'SugarEnt',
    'published_date' => '2022-08-01 11:21:17',
    'type' => 'patch',
    'version' => '11.0.4',
    'flavor' => 'ENT',
);

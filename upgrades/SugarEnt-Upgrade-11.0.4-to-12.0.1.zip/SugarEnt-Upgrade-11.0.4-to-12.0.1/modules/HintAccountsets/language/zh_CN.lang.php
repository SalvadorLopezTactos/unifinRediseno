<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'Hint 帐套表编号';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'Hint 帐套表类型';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'Hint 帐套表用户编号';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'Hint 帐套表用户姓名';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'Hint 帐套表类别';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'Hint 帐套表目标';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'Hint 帐套表通知目标';

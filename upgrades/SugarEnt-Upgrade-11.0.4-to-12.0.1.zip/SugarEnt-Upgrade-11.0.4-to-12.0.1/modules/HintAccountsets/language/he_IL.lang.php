<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'מזהה קבוצת חשבונות ב-Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'סוג קבוצת חשבונות ב-Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'מזהה משתמש קבוצת חשבונות ב-Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'שם משתמש קבוצת חשבונות ב-Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'קטגוריית קבוצת חשבונות ב-Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'יעדי קבוצת חשבונות ב-Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'יעדי הודעות קבוצת חשבונות ב-Hint';

<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'Hint 帳套表編號';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'Hint 帳套表類型';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'Hint 帳套表用戶編號';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'Hint 帳套表用戶姓名';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'Hint 帳套表類別';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'Hint 帳套表目標';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'Hint 帳套表通知目標';

<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = [
    'LBL_FOLDER_ID' => 'ID โฟลเดอร์',
    'LBL_IS_SHARED' => 'แชร์',
    'LBL_IS_ROOT' => 'คือรูท',
    'LBL_TYPE' => 'ประเภท',
    'LBL_CLOUD_PATH' => 'เส้นทาง',
    'LBL_RECORD' => 'ID ระเบียน',
    'LBL_MODULE' => 'โมดูล',
    'LBL_DRIVE_ID' => 'ID ไดร์ฟ',
];

<?php
// created: 2015-06-08 19:33:37
$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REL_RELACIONES_ACCOUNTS_1_FROM_REL_RELACIONES_TITLE',
  'context' => 
  array (
    'link' => 'rel_relaciones_accounts_1',
  ),
);

$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REL_RELACIONES_ACCOUNTS_1_FROM_REL_RELACIONES_TITLE',
  'context' => 
  array (
    'link' => 'rel_relaciones_accounts_1',
  ),
);
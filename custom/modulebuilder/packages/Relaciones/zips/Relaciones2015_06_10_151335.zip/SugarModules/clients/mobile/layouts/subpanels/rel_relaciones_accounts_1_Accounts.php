<?php
// created: 2015-06-08 19:33:38
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REL_RELACIONES_ACCOUNTS_1_FROM_REL_RELACIONES_TITLE',
  'context' => 
  array (
    'link' => 'rel_relaciones_accounts_1',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REL_RELACIONES_ACCOUNTS_1_FROM_REL_RELACIONES_TITLE',
  'context' => 
  array (
    'link' => 'rel_relaciones_accounts_1',
  ),
);
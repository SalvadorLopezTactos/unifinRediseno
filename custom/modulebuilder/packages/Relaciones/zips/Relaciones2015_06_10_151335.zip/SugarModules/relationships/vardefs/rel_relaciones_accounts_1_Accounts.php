<?php
// created: 2015-06-10 15:13:35
$dictionary["Account"]["fields"]["rel_relaciones_accounts_1"] = array (
  'name' => 'rel_relaciones_accounts_1',
  'type' => 'link',
  'relationship' => 'rel_relaciones_accounts_1',
  'source' => 'non-db',
  'module' => 'Rel_Relaciones',
  'bean_name' => 'Rel_Relaciones',
  'vname' => 'LBL_REL_RELACIONES_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'rel_relaciones_accounts_1accounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);

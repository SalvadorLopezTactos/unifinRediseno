<?php
// created: 2015-06-10 15:13:34
$dictionary["Account"]["fields"]["rel_relaciones_accounts"] = array (
  'name' => 'rel_relaciones_accounts',
  'type' => 'link',
  'relationship' => 'rel_relaciones_accounts',
  'source' => 'non-db',
  'module' => 'Rel_Relaciones',
  'bean_name' => 'Rel_Relaciones',
  'vname' => 'LBL_REL_RELACIONES_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'rel_relaciones_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
 // created: 2015-06-10 15:13:35
$layout_defs["Accounts"]["subpanel_setup"]['rel_relaciones_accounts_1'] = array (
  'order' => 100,
  'module' => 'Rel_Relaciones',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_REL_RELACIONES_ACCOUNTS_1_FROM_REL_RELACIONES_TITLE',
  'get_subpanel_data' => 'rel_relaciones_accounts_1',
);

<?php
 // created: 2024-01-22 21:04:00
$layout_defs["TCTBL_Backlog_Seguros"]["subpanel_setup"]['tctbl_backlog_seguros_s_seguros'] = array (
  'order' => 100,
  'module' => 'S_seguros',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_TCTBL_BACKLOG_SEGUROS_S_SEGUROS_FROM_S_SEGUROS_TITLE',
  'get_subpanel_data' => 'tctbl_backlog_seguros_s_seguros',
);

<?php
// created: 2024-01-22 20:59:45
$viewdefs['TCTBL_Backlog_Seguros']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TCTBL_BACKLOG_SEGUROS_S_SEGUROS_1_FROM_S_SEGUROS_TITLE',
  'context' => 
  array (
    'link' => 'tctbl_backlog_seguros_s_seguros_1',
  ),
);

$viewdefs['TCTBL_Backlog_Seguros']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TCTBL_BACKLOG_SEGUROS_S_SEGUROS_1_FROM_S_SEGUROS_TITLE',
  'context' => 
  array (
    'link' => 'tctbl_backlog_seguros_s_seguros_1',
  ),
);

$viewdefs['TCTBL_Backlog_Seguros']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_TCTBL_BACKLOG_SEGUROS_S_SEGUROS_1_FROM_S_SEGUROS_TITLE',
  'context' => 
  array (
    'link' => 'tctbl_backlog_seguros_s_seguros_1',
  ),
);
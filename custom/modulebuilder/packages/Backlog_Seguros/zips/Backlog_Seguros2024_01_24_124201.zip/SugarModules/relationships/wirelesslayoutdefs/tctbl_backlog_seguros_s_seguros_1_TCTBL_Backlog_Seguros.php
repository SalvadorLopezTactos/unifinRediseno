<?php
 // created: 2024-01-24 12:42:01
$layout_defs["TCTBL_Backlog_Seguros"]["subpanel_setup"]['tctbl_backlog_seguros_s_seguros_1'] = array (
  'order' => 100,
  'module' => 'S_seguros',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_TCTBL_BACKLOG_SEGUROS_S_SEGUROS_1_FROM_S_SEGUROS_TITLE',
  'get_subpanel_data' => 'tctbl_backlog_seguros_s_seguros_1',
);

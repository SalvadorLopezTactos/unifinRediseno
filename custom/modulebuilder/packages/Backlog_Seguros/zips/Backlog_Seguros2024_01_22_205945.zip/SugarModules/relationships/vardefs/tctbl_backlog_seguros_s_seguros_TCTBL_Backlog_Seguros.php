<?php
// created: 2024-01-22 20:59:41
$dictionary["TCTBL_Backlog_Seguros"]["fields"]["tctbl_backlog_seguros_s_seguros"] = array (
  'name' => 'tctbl_backlog_seguros_s_seguros',
  'type' => 'link',
  'relationship' => 'tctbl_backlog_seguros_s_seguros',
  'source' => 'non-db',
  'module' => 'S_seguros',
  'bean_name' => 'S_seguros',
  'vname' => 'LBL_TCTBL_BACKLOG_SEGUROS_S_SEGUROS_FROM_TCTBL_BACKLOG_SEGUROS_TITLE',
  'id_name' => 'tctbl_backlog_seguros_s_segurostctbl_backlog_seguros_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favorite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Estructura de Productos List',
  'LBL_MODULE_NAME' => 'Estructura de Productos',
  'LBL_MODULE_TITLE' => 'Estructura de Productos',
  'LBL_MODULE_NAME_SINGULAR' => 'Estructura de Producto',
  'LBL_HOMEPAGE_TITLE' => 'My Estructura de Productos',
  'LNK_NEW_RECORD' => 'Create Estructura de Producto',
  'LNK_LIST' => 'View Estructura de Productos',
  'LNK_IMPORT_PROD_ESTRUCTURA_PRODUCTOS' => 'Importar Estructura de Productos',
  'LBL_SEARCH_FORM_TITLE' => 'Search Estructura de Producto',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activity Stream',
  'LBL_PROD_ESTRUCTURA_PRODUCTOS_SUBPANEL_TITLE' => 'Estructura de Productos',
  'LBL_NEW_FORM_TITLE' => 'New Estructura de Producto',
  'LNK_IMPORT_VCARD' => 'Importar Estructura de Producto vCard',
  'LBL_IMPORT' => 'Importar Estructura de Productos',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Estructura de Producto record by importing a vCard from your file system.',
  'LBL_TIPO_PRODUCTO' => 'Tipo de Producto',
  'LBL_NEGOCIO' => 'Negocio',
  'LBL_PRODUCTO_FINANCIERO' => 'Producto Financiero',
  'LBL_EMPRESA' => 'Empresa',
  'LBL_DISPONIBLE_SELECCION' => 'Disponible para Selección',
);
<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'الفرق',
  'LBL_TEAMS' => 'الفرق',
  'LBL_TEAM_ID' => 'معرّف الفريق',
  'LBL_ASSIGNED_TO_ID' => 'معرّف المستخدم المعين',
  'LBL_ASSIGNED_TO_NAME' => 'تعيين إلى',
  'LBL_TAGS_LINK' => 'العلامات',
  'LBL_TAGS' => 'العلامات',
  'LBL_ID' => 'المعرّف',
  'LBL_DATE_ENTERED' => 'تاريخ الإنشاء',
  'LBL_DATE_MODIFIED' => 'تاريخ التعديل',
  'LBL_MODIFIED' => 'تم التعديل بواسطة',
  'LBL_MODIFIED_ID' => 'تم التعديل بواسطة المعرّف',
  'LBL_MODIFIED_NAME' => 'تم التعديل بواسطة الاسم',
  'LBL_CREATED' => 'تم الإنشاء بواسطة',
  'LBL_CREATED_ID' => 'تم الإنشاء بواسطة المعرّف',
  'LBL_DOC_OWNER' => 'مالك المستند',
  'LBL_USER_FAVORITES' => 'المستخدمون الذي يفضلون',
  'LBL_DESCRIPTION' => 'الوصف',
  'LBL_DELETED' => 'تم الحذف',
  'LBL_NAME' => 'الاسم',
  'LBL_CREATED_USER' => 'تم الإنشاء بواسطة مستخدم',
  'LBL_MODIFIED_USER' => 'تم التعديل بواسطة مستخدم',
  'LBL_LIST_NAME' => 'الاسم',
  'LBL_EDIT_BUTTON' => 'تحرير',
  'LBL_REMOVE' => 'إزالة',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'تم التعديل بواسطة الاسم',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Estructura de Productos القائمة',
  'LBL_MODULE_NAME' => 'Estructura de Productos',
  'LBL_MODULE_TITLE' => 'Estructura de Productos',
  'LBL_MODULE_NAME_SINGULAR' => 'Estructura de Producto',
  'LBL_HOMEPAGE_TITLE' => 'الخاص بي Estructura de Productos',
  'LNK_NEW_RECORD' => 'إنشاء Estructura de Producto',
  'LNK_LIST' => 'عرض Estructura de Productos',
  'LNK_IMPORT_PROD_ESTRUCTURA_PRODUCTOS' => 'Importar Estructura de Productos',
  'LBL_SEARCH_FORM_TITLE' => 'بحث Estructura de Producto',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'عرض السجل',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'سير النشاط الكلي',
  'LBL_PROD_ESTRUCTURA_PRODUCTOS_SUBPANEL_TITLE' => 'Estructura de Productos',
  'LBL_NEW_FORM_TITLE' => 'جديد Estructura de Producto',
  'LNK_IMPORT_VCARD' => 'Importar Estructura de Producto vCard',
  'LBL_IMPORT' => 'Importar Estructura de Productos',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Estructura de Producto record by importing a vCard from your file system.',
  'LBL_TIPO_PRODUCTO' => 'Tipo de Producto',
  'LBL_NEGOCIO' => 'Negocio',
  'LBL_PRODUCTO_FINANCIERO' => 'Producto Financiero',
  'LBL_EMPRESA' => 'Empresa',
  'LBL_DISPONIBLE_SELECCION' => 'Disponible para Selección',
);
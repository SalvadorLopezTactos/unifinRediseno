<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

$app_list_strings['moduleList']['prod_Estructura_Productos'] = 'Estructura de Productos';
$app_list_strings['moduleListSingular']['prod_Estructura_Productos'] = 'Estructura de Producto';
$app_list_strings['Institucion_list']['BANAMEX'] = 'BANAMEX';
$app_list_strings['Institucion_list']['SERFIN'] = 'SERFIN';
$app_list_strings['Institucion_list']['ATLANTICO'] = 'ATLANTICO';
$app_list_strings['Institucion_list']['CITIBANK'] = 'CITIBANK';
$app_list_strings['Institucion_list']['UNION'] = 'UNION';
$app_list_strings['Institucion_list']['CONFIA'] = 'CONFIA';
$app_list_strings['Institucion_list']['BBVA BANCOMER'] = 'BBVA BANCOMER';
$app_list_strings['Institucion_list']['INDUSTRIAL'] = 'INDUSTRIAL';
$app_list_strings['Institucion_list']['SANTANDER'] = 'SANTANDER';
$app_list_strings['Institucion_list']['INTERBANCO'] = 'INTERBANCO';
$app_list_strings['Institucion_list']['BBVA SERVICIOS'] = 'BBVA SERVICIOS';
$app_list_strings['Institucion_list']['HSBC HSBC'] = 'HSBC HSBC';
$app_list_strings['Institucion_list']['GE MONEY'] = 'GE MONEY';
$app_list_strings['Institucion_list']['SURESTE'] = 'SURESTE';
$app_list_strings['Institucion_list']['CAPITAL'] = 'CAPITAL';
$app_list_strings['Institucion_list']['BAJIO'] = 'BAJIO';
$app_list_strings['Institucion_list']['IXE'] = 'IXE';
$app_list_strings['Institucion_list']['INBURSA'] = 'INBURSA';
$app_list_strings['Institucion_list']['INTERACCIONES'] = 'INTERACCIONES';
$app_list_strings['Institucion_list']['MIFEL'] = 'MIFEL';
$app_list_strings['Institucion_list']['INVERLAT'] = 'INVERLAT';
$app_list_strings['Institucion_list']['PRONORTE'] = 'PRONORTE';
$app_list_strings['Institucion_list']['QUADRUM'] = 'QUADRUM';
$app_list_strings['Institucion_list']['BANREGIO'] = 'BANREGIO';
$app_list_strings['Institucion_list']['INVEX'] = 'INVEX';
$app_list_strings['Institucion_list']['BANSI'] = 'BANSI';
$app_list_strings['Institucion_list']['AFIRME'] = 'AFIRME';
$app_list_strings['Institucion_list']['ANAHUAC'] = 'ANAHUAC';
$app_list_strings['Institucion_list']['PROMEX'] = 'PROMEX';
$app_list_strings['Institucion_list']['BANPAIS'] = 'BANPAIS';
$app_list_strings['Institucion_list']['BANORTE/IXE'] = 'BANORTE/IXE';
$app_list_strings['Institucion_list']['ORIENTE'] = 'ORIENTE';
$app_list_strings['Institucion_list']['BANCEN'] = 'BANCEN';
$app_list_strings['Institucion_list']['CREMI'] = 'CREMI';
$app_list_strings['Institucion_list']['INVESTA BANK'] = 'INVESTA BANK';
$app_list_strings['Institucion_list']['AMERICAN EXPRESS'] = 'AMERICAN EXPRESS';
$app_list_strings['Institucion_list']['BAMSA'] = 'BAMSA';
$app_list_strings['Institucion_list']['BOSTON'] = 'BOSTON';
$app_list_strings['Institucion_list']['TOKYO'] = 'TOKYO';
$app_list_strings['Institucion_list']['BNP'] = 'BNP';
$app_list_strings['Institucion_list']['JP MORGAN'] = 'JP MORGAN';
$app_list_strings['Institucion_list']['MONEX'] = 'MONEX';
$app_list_strings['Institucion_list']['BANK ONE'] = 'BANK ONE';
$app_list_strings['Institucion_list']['FUJI'] = 'FUJI';
$app_list_strings['Institucion_list']['ING'] = 'ING';
$app_list_strings['Institucion_list']['NATIONSBANK'] = 'NATIONSBANK';
$app_list_strings['Institucion_list']['REPUBLIC NY'] = 'REPUBLIC NY';
$app_list_strings['Institucion_list']['SOCIETE'] = 'SOCIETE';
$app_list_strings['Institucion_list']['DEUTSCHE'] = 'DEUTSCHE';
$app_list_strings['Institucion_list']['Credit Suisse First Boston'] = 'Credit Suisse First Boston';
$app_list_strings['Institucion_list']['AZTECA'] = 'AZTECA';
$app_list_strings['Institucion_list']['AUTOFIN'] = 'AUTOFIN';
$app_list_strings['Institucion_list']['BARCLAYS'] = 'BARCLAYS';
$app_list_strings['Institucion_list']['COMPARTAMOS'] = 'COMPARTAMOS';
$app_list_strings['Institucion_list']['BANCO FAMSA'] = 'BANCO FAMSA';
$app_list_strings['Institucion_list']['MULTIVA BANCO'] = 'MULTIVA BANCO';
$app_list_strings['Institucion_list']['BM ACTINVER'] = 'BM ACTINVER';
$app_list_strings['Institucion_list']['WAL-MART'] = 'WAL-MART';
$app_list_strings['Institucion_list']['INTERCAM BANCO'] = 'INTERCAM BANCO';
$app_list_strings['Institucion_list']['BANCOPPEL'] = 'BANCOPPEL';
$app_list_strings['Institucion_list']['ABC CAPITAL'] = 'ABC CAPITAL';
$app_list_strings['Institucion_list']['UBS BANK'] = 'UBS BANK';
$app_list_strings['Institucion_list']['CONSUBANCO'] = 'CONSUBANCO';
$app_list_strings['Institucion_list']['VOLKSWAGEN'] = 'VOLKSWAGEN';
$app_list_strings['Institucion_list']['CIBANCO'] = 'CIBANCO';
$app_list_strings['Institucion_list']['BANK NEW YORK'] = 'BANK NEW YORK';
$app_list_strings['Institucion_list']['BM BASE'] = 'BM BASE';
$app_list_strings['Institucion_list']['BICENTENARIO'] = 'BICENTENARIO';
$app_list_strings['Institucion_list']['BANKAOOL'] = 'BANKAOOL';
$app_list_strings['Institucion_list']['PAGATODO'] = 'PAGATODO';
$app_list_strings['Institucion_list']['FORJADORES'] = 'FORJADORES';
$app_list_strings['Institucion_list']['INMOBILIARIO'] = 'INMOBILIARIO';
$app_list_strings['Institucion_list']['DONDE'] = 'DONDE';
$app_list_strings['Institucion_list']['BANCREA'] = 'BANCREA';
$app_list_strings['Institucion_list']['PROGRESO'] = 'PROGRESO';
$app_list_strings['Institucion_list']['BANCO FINTERRA'] = 'BANCO FINTERRA';
$app_list_strings['Institucion_list']['ICBC'] = 'ICBC';
$app_list_strings['Institucion_list']['SABADELL'] = 'SABADELL';
$app_list_strings['Institucion_list']['SHINHAN'] = 'SHINHAN';
$app_list_strings['Institucion_list']['MIZUHO BANK'] = 'MIZUHO BANK';
$app_list_strings['Institucion_list']['BANK OF CHINA'] = 'BANK OF CHINA';
$app_list_strings['Institucion_list']['BANCO S3'] = 'BANCO S3';
$app_list_strings['Institucion_list']['BANORTE'] = 'BANORTE';
$app_list_strings['Institucion_list']['OBRERO'] = 'OBRERO';
$app_list_strings['Institucion_list']['BXMAS'] = 'BX+';
$app_list_strings['Institucion_list'][''] = '';

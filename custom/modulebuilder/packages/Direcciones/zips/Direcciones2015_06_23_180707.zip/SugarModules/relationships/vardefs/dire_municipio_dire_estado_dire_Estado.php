<?php
// created: 2015-06-23 18:06:59
$dictionary["dire_Estado"]["fields"]["dire_municipio_dire_estado"] = array (
  'name' => 'dire_municipio_dire_estado',
  'type' => 'link',
  'relationship' => 'dire_municipio_dire_estado',
  'source' => 'non-db',
  'module' => 'dire_Municipio',
  'bean_name' => 'dire_Municipio',
  'vname' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_ESTADO_TITLE',
  'id_name' => 'dire_municipio_dire_estadodire_estado_ida',
  'link-type' => 'many',
  'side' => 'left',
);

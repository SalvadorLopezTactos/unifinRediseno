<?php
// created: 2015-06-23 18:07:05
$dictionary["dire_CodigoPostal"]["fields"]["dire_direccion_dire_codigopostal"] = array (
  'name' => 'dire_direccion_dire_codigopostal',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_codigopostal',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_CODIGOPOSTAL_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'id_name' => 'dire_direccion_dire_codigopostaldire_codigopostal_ida',
  'link-type' => 'many',
  'side' => 'left',
);

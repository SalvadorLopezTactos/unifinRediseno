<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipe',
  'LBL_TEAMS' => 'Equipes',
  'LBL_TEAM_ID' => 'Equipe (ID)',
  'LBL_ASSIGNED_TO_ID' => 'Assigné à (ID)',
  'LBL_ASSIGNED_TO_NAME' => 'Assigné à',
  'LBL_CREATED' => 'Créé par',
  'LBL_CREATED_ID' => 'Créé par (ID)',
  'LBL_CREATED_USER' => 'Créé par',
  'LBL_DATE_ENTERED' => 'Date de création',
  'LBL_DATE_MODIFIED' => 'Date de modification',
  'LBL_DELETED' => 'Supprimé',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DOC_OWNER' => 'Propriétaire du document',
  'LBL_EDIT_BUTTON' => 'Editer',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_MODIFIED' => 'Modifié par',
  'LBL_MODIFIED_ID' => 'Modifié par (ID)',
  'LBL_MODIFIED_NAME' => 'Modifié par',
  'LBL_MODIFIED_USER' => 'Modifié par',
  'LBL_NAME' => 'Nom',
  'LBL_REMOVE' => 'Supprimer',
  'LBL_USER_FAVORITES' => 'Favoris pour les utilisateurs suivants',
  'LBL_LIST_FORM_TITLE' => 'Colonias Liste',
  'LBL_MODULE_NAME' => 'Colonias',
  'LBL_MODULE_TITLE' => 'Colonias',
  'LBL_MODULE_NAME_SINGULAR' => 'Colonia',
  'LBL_HOMEPAGE_TITLE' => 'Mes Colonias',
  'LNK_NEW_RECORD' => 'Créer Colonia',
  'LNK_LIST' => 'Vue Colonias',
  'LNK_IMPORT_DIRE_COLONIA' => 'Importar Colonia',
  'LBL_SEARCH_FORM_TITLE' => 'Recherche Colonia',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Voir l&#39;Historique',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activités',
  'LBL_DIRE_COLONIA_SUBPANEL_TITLE' => 'Colonias',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Colonia',
  'LNK_IMPORT_VCARD' => 'Importar Colonia vCard',
  'LBL_IMPORT' => 'Importar Colonias',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Colonia record by importing a vCard from your file system.',
  'LBL_CODIGOPOSTAL_DIRE_COLONIA_ID' => 'codigopostal (related Colonia ID)',
  'LBL_CODIGOPOSTAL' => 'codigopostal',
  'LBL_CODIGO_POSTAL' => 'Codigo Postal',
);
<?php
// created: 2015-06-08 15:01:22
$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);

$viewdefs['dire_Pais']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'context' => 
  array (
    'link' => 'dire_estado_dire_pais',
  ),
);
<?php
// created: 2015-06-08 15:01:27
$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);

$viewdefs['dire_Pais']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_pais',
  ),
);
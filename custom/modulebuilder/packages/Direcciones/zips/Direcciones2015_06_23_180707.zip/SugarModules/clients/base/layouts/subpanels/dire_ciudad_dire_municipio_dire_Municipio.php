<?php
// created: 2015-06-08 16:18:00
$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_municipio',
  ),
);
<?php
// created: 2015-06-08 15:01:27
$dictionary["dire_Colonia"]["fields"]["dire_direccion_dire_colonia"] = array (
  'name' => 'dire_direccion_dire_colonia',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_colonia',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_COLONIA_FROM_DIRE_COLONIA_TITLE',
  'id_name' => 'dire_direccion_dire_coloniadire_colonia_ida',
  'link-type' => 'many',
  'side' => 'left',
);

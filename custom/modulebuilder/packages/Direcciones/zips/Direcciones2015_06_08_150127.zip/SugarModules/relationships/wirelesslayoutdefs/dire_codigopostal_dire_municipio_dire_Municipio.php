<?php
 // created: 2015-06-08 15:01:24
$layout_defs["dire_Municipio"]["subpanel_setup"]['dire_codigopostal_dire_municipio'] = array (
  'order' => 100,
  'module' => 'dire_CodigoPostal',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_MUNICIPIO_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'get_subpanel_data' => 'dire_codigopostal_dire_municipio',
);

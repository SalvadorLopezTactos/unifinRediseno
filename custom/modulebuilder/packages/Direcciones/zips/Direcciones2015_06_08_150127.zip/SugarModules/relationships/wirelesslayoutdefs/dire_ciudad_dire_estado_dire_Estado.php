<?php
 // created: 2015-06-08 15:01:22
$layout_defs["dire_Estado"]["subpanel_setup"]['dire_ciudad_dire_estado'] = array (
  'order' => 100,
  'module' => 'dire_Ciudad',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIRE_CIUDAD_DIRE_ESTADO_FROM_DIRE_CIUDAD_TITLE',
  'get_subpanel_data' => 'dire_ciudad_dire_estado',
);

<?php
// created: 2015-06-08 15:01:25
$dictionary["dire_Pais"]["fields"]["dire_direccion_dire_pais"] = array (
  'name' => 'dire_direccion_dire_pais',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_pais',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_PAIS_TITLE',
  'id_name' => 'dire_direccion_dire_paisdire_pais_ida',
  'link-type' => 'many',
  'side' => 'left',
);

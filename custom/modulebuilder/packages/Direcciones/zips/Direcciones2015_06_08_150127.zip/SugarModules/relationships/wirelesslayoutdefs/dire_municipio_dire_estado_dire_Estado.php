<?php
 // created: 2015-06-08 15:01:23
$layout_defs["dire_Estado"]["subpanel_setup"]['dire_municipio_dire_estado'] = array (
  'order' => 100,
  'module' => 'dire_Municipio',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'get_subpanel_data' => 'dire_municipio_dire_estado',
);

<?php
 // created: 2015-06-08 15:01:22
$layout_defs["dire_Pais"]["subpanel_setup"]['dire_estado_dire_pais'] = array (
  'order' => 100,
  'module' => 'dire_Estado',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIRE_ESTADO_DIRE_PAIS_FROM_DIRE_ESTADO_TITLE',
  'get_subpanel_data' => 'dire_estado_dire_pais',
);

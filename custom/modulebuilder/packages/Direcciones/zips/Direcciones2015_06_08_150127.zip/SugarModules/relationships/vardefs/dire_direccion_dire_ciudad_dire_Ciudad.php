<?php
// created: 2015-06-08 15:01:26
$dictionary["dire_Ciudad"]["fields"]["dire_direccion_dire_ciudad"] = array (
  'name' => 'dire_direccion_dire_ciudad',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_ciudad',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_CIUDAD_FROM_DIRE_CIUDAD_TITLE',
  'id_name' => 'dire_direccion_dire_ciudaddire_ciudad_ida',
  'link-type' => 'many',
  'side' => 'left',
);

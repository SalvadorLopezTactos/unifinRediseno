<?php
 // created: 2015-06-08 15:01:27
$layout_defs["dire_Colonia"]["subpanel_setup"]['dire_direccion_dire_colonia'] = array (
  'order' => 100,
  'module' => 'dire_Direccion',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIRE_DIRECCION_DIRE_COLONIA_FROM_DIRE_DIRECCION_TITLE',
  'get_subpanel_data' => 'dire_direccion_dire_colonia',
);

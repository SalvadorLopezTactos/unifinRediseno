<?php
 // created: 2015-06-08 15:01:24
$layout_defs["dire_CodigoPostal"]["subpanel_setup"]['dire_colonia_dire_codigopostal'] = array (
  'order' => 100,
  'module' => 'dire_Colonia',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DIRE_COLONIA_DIRE_CODIGOPOSTAL_FROM_DIRE_COLONIA_TITLE',
  'get_subpanel_data' => 'dire_colonia_dire_codigopostal',
);

<?php
// created: 2015-06-08 15:01:27
$viewdefs['dire_CodigoPostal']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_CODIGOPOSTAL_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_codigopostal',
  ),
);
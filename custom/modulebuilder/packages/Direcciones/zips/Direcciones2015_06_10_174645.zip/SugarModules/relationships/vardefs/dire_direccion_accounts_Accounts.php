<?php
// created: 2015-06-10 17:46:45
$dictionary["Account"]["fields"]["dire_direccion_accounts"] = array (
  'name' => 'dire_direccion_accounts',
  'type' => 'link',
  'relationship' => 'dire_direccion_accounts',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => false,
  'vname' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_DIRE_DIRECCION_TITLE',
  'id_name' => 'dire_direccion_accountsdire_direccion_ida',
);

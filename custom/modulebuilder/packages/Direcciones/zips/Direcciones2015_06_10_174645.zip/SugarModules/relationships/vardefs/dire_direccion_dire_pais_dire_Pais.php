<?php
// created: 2015-06-10 17:46:42
$dictionary["dire_Pais"]["fields"]["dire_direccion_dire_pais"] = array (
  'name' => 'dire_direccion_dire_pais',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_pais',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => false,
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_PAIS_FROM_DIRE_PAIS_TITLE',
  'id_name' => 'dire_direccion_dire_paisdire_pais_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
// created: 2015-06-10 17:46:42
$dictionary["dire_Ciudad"]["fields"]["dire_codigopostal_dire_ciudad"] = array (
  'name' => 'dire_codigopostal_dire_ciudad',
  'type' => 'link',
  'relationship' => 'dire_codigopostal_dire_ciudad',
  'source' => 'non-db',
  'module' => 'dire_CodigoPostal',
  'bean_name' => false,
  'vname' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CIUDAD_TITLE',
  'id_name' => 'dire_codigopostal_dire_ciudaddire_ciudad_ida',
  'link-type' => 'many',
  'side' => 'left',
);

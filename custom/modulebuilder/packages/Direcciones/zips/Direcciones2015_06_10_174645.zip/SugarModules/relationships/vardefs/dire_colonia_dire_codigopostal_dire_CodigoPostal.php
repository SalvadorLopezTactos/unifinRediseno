<?php
// created: 2015-06-10 17:46:41
$dictionary["dire_CodigoPostal"]["fields"]["dire_colonia_dire_codigopostal"] = array (
  'name' => 'dire_colonia_dire_codigopostal',
  'type' => 'link',
  'relationship' => 'dire_colonia_dire_codigopostal',
  'source' => 'non-db',
  'module' => 'dire_Colonia',
  'bean_name' => false,
  'vname' => 'LBL_DIRE_COLONIA_DIRE_CODIGOPOSTAL_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'id_name' => 'dire_colonia_dire_codigopostaldire_codigopostal_ida',
  'link-type' => 'many',
  'side' => 'left',
);

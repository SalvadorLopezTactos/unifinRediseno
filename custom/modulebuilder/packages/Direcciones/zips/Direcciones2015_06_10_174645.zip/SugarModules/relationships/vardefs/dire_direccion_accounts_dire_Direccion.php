<?php
// created: 2015-06-10 17:46:45
$dictionary["dire_Direccion"]["fields"]["dire_direccion_accounts"] = array (
  'name' => 'dire_direccion_accounts',
  'type' => 'link',
  'relationship' => 'dire_direccion_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'dire_direccion_accountsaccounts_idb',
);

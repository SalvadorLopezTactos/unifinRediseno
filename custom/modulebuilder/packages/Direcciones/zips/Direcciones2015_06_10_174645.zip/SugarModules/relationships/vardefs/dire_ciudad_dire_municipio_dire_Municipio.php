<?php
// created: 2015-06-10 17:46:38
$dictionary["dire_Municipio"]["fields"]["dire_ciudad_dire_municipio"] = array (
  'name' => 'dire_ciudad_dire_municipio',
  'type' => 'link',
  'relationship' => 'dire_ciudad_dire_municipio',
  'source' => 'non-db',
  'module' => 'dire_Ciudad',
  'bean_name' => false,
  'vname' => 'LBL_DIRE_CIUDAD_DIRE_MUNICIPIO_FROM_DIRE_MUNICIPIO_TITLE',
  'id_name' => 'dire_ciudad_dire_municipiodire_municipio_ida',
  'link-type' => 'many',
  'side' => 'left',
);

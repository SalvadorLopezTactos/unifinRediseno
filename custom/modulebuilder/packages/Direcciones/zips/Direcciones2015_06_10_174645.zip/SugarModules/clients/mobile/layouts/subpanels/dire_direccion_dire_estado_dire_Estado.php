<?php
// created: 2015-06-08 15:01:27
$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);

$viewdefs['dire_Estado']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_dire_estado',
  ),
);
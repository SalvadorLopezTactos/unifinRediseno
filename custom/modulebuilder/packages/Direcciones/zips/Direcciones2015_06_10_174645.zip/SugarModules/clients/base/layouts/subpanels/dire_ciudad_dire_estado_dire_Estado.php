<?php
// created: 2015-06-08 15:01:21
$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_ESTADO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CIUDAD_DIRE_ESTADO_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_ciudad_dire_estado',
  ),
);
<?php
// created: 2015-06-08 15:01:23
$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);

$viewdefs['dire_Estado']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_ESTADO_FROM_DIRE_MUNICIPIO_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_estado',
  ),
);
<?php
// created: 2015-06-08 15:33:05
$dictionary["dire_Municipio"]["fields"]["dire_codigopostal_dire_municipio"] = array (
  'name' => 'dire_codigopostal_dire_municipio',
  'type' => 'link',
  'relationship' => 'dire_codigopostal_dire_municipio',
  'source' => 'non-db',
  'module' => 'dire_CodigoPostal',
  'bean_name' => 'dire_CodigoPostal',
  'vname' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_MUNICIPIO_FROM_DIRE_MUNICIPIO_TITLE',
  'id_name' => 'dire_codigopostal_dire_municipiodire_municipio_ida',
  'link-type' => 'many',
  'side' => 'left',
);

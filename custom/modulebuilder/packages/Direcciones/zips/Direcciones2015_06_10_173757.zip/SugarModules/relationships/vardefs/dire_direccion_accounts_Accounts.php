<?php
// created: 2015-06-10 17:37:57
$dictionary["Account"]["fields"]["dire_direccion_accounts"] = array (
  'name' => 'dire_direccion_accounts',
  'type' => 'link',
  'relationship' => 'dire_direccion_accounts',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'dire_direccion_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);

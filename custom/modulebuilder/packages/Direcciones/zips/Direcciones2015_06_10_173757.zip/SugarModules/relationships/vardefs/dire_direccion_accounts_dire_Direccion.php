<?php
// created: 2015-06-10 17:37:57
$dictionary["dire_Direccion"]["fields"]["dire_direccion_accounts"] = array (
  'name' => 'dire_direccion_accounts',
  'type' => 'link',
  'relationship' => 'dire_direccion_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_DIRE_DIRECCION_TITLE',
  'id_name' => 'dire_direccion_accountsaccounts_ida',
  'link-type' => 'one',
);
$dictionary["dire_Direccion"]["fields"]["dire_direccion_accounts_name"] = array (
  'name' => 'dire_direccion_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'dire_direccion_accountsaccounts_ida',
  'link' => 'dire_direccion_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["dire_Direccion"]["fields"]["dire_direccion_accountsaccounts_ida"] = array (
  'name' => 'dire_direccion_accountsaccounts_ida',
  'type' => 'id',
  'source' => 'non-db',
  'vname' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_DIRE_DIRECCION_TITLE_ID',
  'id_name' => 'dire_direccion_accountsaccounts_ida',
  'link' => 'dire_direccion_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'id',
  'reportable' => false,
  'side' => 'right',
  'massupdate' => false,
  'duplicate_merge' => 'disabled',
  'hideacl' => true,
);

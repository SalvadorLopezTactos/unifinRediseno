<?php
// created: 2015-06-08 15:33:00
$dictionary["dire_Estado"]["fields"]["dire_ciudad_dire_estado"] = array (
  'name' => 'dire_ciudad_dire_estado',
  'type' => 'link',
  'relationship' => 'dire_ciudad_dire_estado',
  'source' => 'non-db',
  'module' => 'dire_Ciudad',
  'bean_name' => 'dire_Ciudad',
  'vname' => 'LBL_DIRE_CIUDAD_DIRE_ESTADO_FROM_DIRE_ESTADO_TITLE',
  'id_name' => 'dire_ciudad_dire_estadodire_estado_ida',
  'link-type' => 'many',
  'side' => 'left',
);

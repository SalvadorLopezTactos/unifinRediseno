<?php
// created: 2015-06-10 17:37:55
$dictionary["dire_Municipio"]["fields"]["dire_direccion_dire_municipio"] = array (
  'name' => 'dire_direccion_dire_municipio',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_municipio',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => 'dire_Direccion',
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_MUNICIPIO_FROM_DIRE_MUNICIPIO_TITLE',
  'id_name' => 'dire_direccion_dire_municipiodire_municipio_ida',
  'link-type' => 'many',
  'side' => 'left',
);

<?php
// created: 2015-06-08 16:18:06
$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);

$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);

$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);

$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);

$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);

$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);

$viewdefs['dire_Ciudad']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_CIUDAD_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_ciudad',
  ),
);
<?php
// created: 2015-06-08 16:18:04
$viewdefs['dire_Municipio']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_CIUDAD_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_ciudad',
  ),
);
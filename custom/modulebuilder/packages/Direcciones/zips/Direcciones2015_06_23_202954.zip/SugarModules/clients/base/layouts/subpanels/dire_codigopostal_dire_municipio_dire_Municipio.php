<?php
// created: 2015-06-08 15:01:24
$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_MUNICIPIO_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_MUNICIPIO_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_MUNICIPIO_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_municipio',
  ),
);

$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_CODIGOPOSTAL_DIRE_MUNICIPIO_FROM_DIRE_CODIGOPOSTAL_TITLE',
  'context' => 
  array (
    'link' => 'dire_codigopostal_dire_municipio',
  ),
);
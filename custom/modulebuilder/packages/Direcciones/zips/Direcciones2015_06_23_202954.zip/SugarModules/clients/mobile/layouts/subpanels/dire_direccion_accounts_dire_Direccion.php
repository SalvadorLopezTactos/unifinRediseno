<?php
// created: 2015-06-10 14:55:44
$viewdefs['dire_Direccion']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_accounts',
  ),
);

$viewdefs['dire_Direccion']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_accounts',
  ),
);
<?php
// created: 2015-06-10 15:01:43
$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_accounts',
  ),
);

$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_accounts',
  ),
);

$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_DIRECCION_ACCOUNTS_FROM_DIRE_DIRECCION_TITLE',
  'context' => 
  array (
    'link' => 'dire_direccion_accounts',
  ),
);
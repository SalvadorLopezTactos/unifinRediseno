<?php
// created: 2015-06-08 16:18:03
$viewdefs['dire_Municipio']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DIRE_MUNICIPIO_DIRE_CIUDAD_FROM_DIRE_CIUDAD_TITLE',
  'context' => 
  array (
    'link' => 'dire_municipio_dire_ciudad',
  ),
);
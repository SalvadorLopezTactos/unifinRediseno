<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'チーム',
  'LBL_TEAMS' => 'チーム',
  'LBL_TEAM_ID' => 'チームID',
  'LBL_ASSIGNED_TO_ID' => 'アサイン先ID',
  'LBL_ASSIGNED_TO_NAME' => 'アサイン先',
  'LBL_CREATED' => '作成者',
  'LBL_CREATED_ID' => '作成者ID',
  'LBL_CREATED_USER' => '作成者',
  'LBL_DATE_ENTERED' => '作成日',
  'LBL_DATE_MODIFIED' => '更新日',
  'LBL_DELETED' => '削除済み',
  'LBL_DESCRIPTION' => '詳細',
  'LBL_DOC_OWNER' => 'ドキュメントの所有者',
  'LBL_EDIT_BUTTON' => '編集',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => '名前',
  'LBL_MODIFIED' => '更新者',
  'LBL_MODIFIED_ID' => '更新者ID',
  'LBL_MODIFIED_NAME' => '更新者',
  'LBL_MODIFIED_USER' => '更新者',
  'LBL_NAME' => '名前',
  'LBL_REMOVE' => '削除',
  'LBL_USER_FAVORITES' => 'お気に入りのユーザー',
  'LBL_LIST_FORM_TITLE' => 'Colonias 一覧',
  'LBL_MODULE_NAME' => 'Colonias',
  'LBL_MODULE_TITLE' => 'Colonias',
  'LBL_MODULE_NAME_SINGULAR' => 'Colonia',
  'LBL_HOMEPAGE_TITLE' => '私の Colonias',
  'LNK_NEW_RECORD' => '作成 Colonia',
  'LNK_LIST' => '画面 Colonias',
  'LNK_IMPORT_DIRE_COLONIA' => 'Importar Colonia',
  'LBL_SEARCH_FORM_TITLE' => '検索 Colonia',
  'LBL_HISTORY_SUBPANEL_TITLE' => '履歴',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => '活動',
  'LBL_DIRE_COLONIA_SUBPANEL_TITLE' => 'Colonias',
  'LBL_NEW_FORM_TITLE' => '新規 Colonia',
  'LNK_IMPORT_VCARD' => 'Importar Colonia vCard',
  'LBL_IMPORT' => 'Importar Colonias',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Colonia record by importing a vCard from your file system.',
  'LBL_CODIGOPOSTAL_DIRE_COLONIA_ID' => 'codigopostal (related Colonia ID)',
  'LBL_CODIGOPOSTAL' => 'codigopostal',
  'LBL_CODIGO_POSTAL' => 'Codigo Postal',
);
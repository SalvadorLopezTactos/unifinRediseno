<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Екип',
  'LBL_TEAMS' => 'Екип',
  'LBL_TEAM_ID' => 'Екип',
  'LBL_ASSIGNED_TO_ID' => 'Отговорник',
  'LBL_ASSIGNED_TO_NAME' => 'Потребител',
  'LBL_CREATED' => 'Създадено от',
  'LBL_CREATED_ID' => 'Създадено от',
  'LBL_CREATED_USER' => 'Създадено от потребител',
  'LBL_DATE_ENTERED' => 'Създадено на',
  'LBL_DATE_MODIFIED' => 'Модифицирано на',
  'LBL_DELETED' => 'Изтрити',
  'LBL_DESCRIPTION' => 'Описание',
  'LBL_DOC_OWNER' => 'Собственик на документа',
  'LBL_EDIT_BUTTON' => 'Редактирай',
  'LBL_ID' => 'Идентификатор',
  'LBL_LIST_NAME' => 'Име',
  'LBL_MODIFIED' => 'Модифицирано от',
  'LBL_MODIFIED_ID' => 'Модифицирано от',
  'LBL_MODIFIED_NAME' => 'Модифицирано от',
  'LBL_MODIFIED_USER' => 'Модифицирано от потребител',
  'LBL_NAME' => 'Име',
  'LBL_REMOVE' => 'Премахни',
  'LBL_USER_FAVORITES' => 'Потребители които харесват',
  'LBL_LIST_FORM_TITLE' => 'Pais Списък',
  'LBL_MODULE_NAME' => 'Pais',
  'LBL_MODULE_TITLE' => 'Pais',
  'LBL_MODULE_NAME_SINGULAR' => 'Pais',
  'LBL_HOMEPAGE_TITLE' => 'Мои Pais',
  'LNK_NEW_RECORD' => 'Създай Pais',
  'LNK_LIST' => 'Разгледай Pais',
  'LNK_IMPORT_DIRE_PAIS' => 'Importar Pais',
  'LBL_SEARCH_FORM_TITLE' => 'Търси Pais',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'История',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Дейности',
  'LBL_DIRE_PAIS_SUBPANEL_TITLE' => 'Pais',
  'LBL_NEW_FORM_TITLE' => 'Нов Pais',
  'LNK_IMPORT_VCARD' => 'Importar Pais vCard',
  'LBL_IMPORT' => 'Importar Pais',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Pais record by importing a vCard from your file system.',
  'LBL_NACIONALIDAD' => 'Nacionalidad',
  'LBL_JURISDICCIONNOCOOPERATIVA' => 'jurisdiccionnocooperativa',
  'LBL_PARAISOFISCAL' => 'paraisofiscal',
  'LBL_LADA' => 'Lada',
  'LBL_CLAVEBURO' => 'Clave Buro',
  'LBL_CODIGODELPAIS' => 'Codigo de el Pais',
  'LBL_ALTORIESGO' => 'Alto Riesgo',
);
<?php
// created: 2015-06-23 20:29:52
$dictionary["dire_Estado"]["fields"]["dire_direccion_dire_estado"] = array (
  'name' => 'dire_direccion_dire_estado',
  'type' => 'link',
  'relationship' => 'dire_direccion_dire_estado',
  'source' => 'non-db',
  'module' => 'dire_Direccion',
  'bean_name' => false,
  'vname' => 'LBL_DIRE_DIRECCION_DIRE_ESTADO_FROM_DIRE_ESTADO_TITLE',
  'id_name' => 'dire_direccion_dire_estadodire_estado_ida',
  'link-type' => 'many',
  'side' => 'left',
);

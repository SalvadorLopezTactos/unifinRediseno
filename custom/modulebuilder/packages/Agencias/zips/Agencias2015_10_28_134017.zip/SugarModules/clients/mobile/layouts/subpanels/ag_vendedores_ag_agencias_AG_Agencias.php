<?php
// created: 2015-10-28 13:22:51
$viewdefs['AG_Agencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_AG_VENDEDORES_AG_AGENCIAS_FROM_AG_VENDEDORES_TITLE',
  'context' => 
  array (
    'link' => 'ag_vendedores_ag_agencias',
  ),
);

$viewdefs['AG_Agencias']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_AG_VENDEDORES_AG_AGENCIAS_FROM_AG_VENDEDORES_TITLE',
  'context' => 
  array (
    'link' => 'ag_vendedores_ag_agencias',
  ),
);
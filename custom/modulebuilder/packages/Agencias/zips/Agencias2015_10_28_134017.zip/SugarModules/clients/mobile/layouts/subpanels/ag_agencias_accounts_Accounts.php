<?php
// created: 2015-10-28 13:22:52
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_AG_AGENCIAS_ACCOUNTS_FROM_AG_AGENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'ag_agencias_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_AG_AGENCIAS_ACCOUNTS_FROM_AG_AGENCIAS_TITLE',
  'context' => 
  array (
    'link' => 'ag_agencias_accounts',
  ),
);
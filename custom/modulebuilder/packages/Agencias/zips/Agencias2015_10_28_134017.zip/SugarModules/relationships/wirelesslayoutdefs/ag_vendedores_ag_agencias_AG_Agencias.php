<?php
 // created: 2015-10-28 13:40:16
$layout_defs["AG_Agencias"]["subpanel_setup"]['ag_vendedores_ag_agencias'] = array (
  'order' => 100,
  'module' => 'AG_Vendedores',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_AG_VENDEDORES_AG_AGENCIAS_FROM_AG_VENDEDORES_TITLE',
  'get_subpanel_data' => 'ag_vendedores_ag_agencias',
);

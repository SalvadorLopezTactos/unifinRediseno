<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Ομάδες',
  'LBL_TEAMS' => 'Ομάδες',
  'LBL_TEAM_ID' => 'Ταυτότητα Ομάδας',
  'LBL_ASSIGNED_TO_ID' => 'Ταυτότητα Ανατεθειμένου Χρήστη',
  'LBL_ASSIGNED_TO_NAME' => 'Ανατέθηκε σε',
  'LBL_CREATED' => 'Δημιουργήθηκε Από',
  'LBL_CREATED_ID' => 'Δημιουργήθηκε Από Ταυτότητα',
  'LBL_CREATED_USER' => 'Δημιουργήθηκε Από Χρήστη',
  'LBL_DATE_ENTERED' => 'Ημερομηνία Δημιουργίας',
  'LBL_DATE_MODIFIED' => 'Ημερομηνία Τροποποίησης',
  'LBL_DELETED' => 'Διαγράφηκε',
  'LBL_DESCRIPTION' => 'Περιγραφή',
  'LBL_DOC_OWNER' => 'Έγγραφο Ιδιοκτήτη',
  'LBL_EDIT_BUTTON' => 'Επεξεργασία',
  'LBL_ID' => 'Ταυτότητα',
  'LBL_LIST_NAME' => 'Όνομα',
  'LBL_MODIFIED' => 'Τροποποιήθηκε Από',
  'LBL_MODIFIED_ID' => 'Τροποποιήθηκε Από Ταυτότητα',
  'LBL_MODIFIED_NAME' => 'Τροποποιήθηκε Από Όνομα',
  'LBL_MODIFIED_USER' => 'Τροποποιήθηκε από Χρήστη',
  'LBL_NAME' => 'Όνομα',
  'LBL_REMOVE' => 'Αφαίρεση',
  'LBL_USER_FAVORITES' => 'Αγαπημένα Χρηστών',
  'LBL_LIST_FORM_TITLE' => 'Referencias Bancarias Λίστα',
  'LBL_MODULE_NAME' => 'Referencias Bancarias',
  'LBL_MODULE_TITLE' => 'Referencias Bancarias',
  'LBL_MODULE_NAME_SINGULAR' => 'Referencia Bancaria',
  'LBL_HOMEPAGE_TITLE' => 'Δική Μου Referencias Bancarias',
  'LNK_NEW_RECORD' => 'Δημιουργία Referencia Bancaria',
  'LNK_LIST' => 'Προβολή Referencias Bancarias',
  'LNK_IMPORT_REFBA_REFERENCIA_BANCARIA' => 'Importar Referencia Bancaria',
  'LBL_SEARCH_FORM_TITLE' => 'Αναζήτηση Referencia Bancaria',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Προβολή Ιστορικού',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Δραστηριότητες',
  'LBL_REFBA_REFERENCIA_BANCARIA_SUBPANEL_TITLE' => 'Referencias Bancarias',
  'LBL_NEW_FORM_TITLE' => 'Νέα Referencia Bancaria',
  'LNK_IMPORT_VCARD' => 'Importar Referencia Bancaria vCard',
  'LBL_IMPORT' => 'Importar Referencias Bancarias',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Referencia Bancaria record by importing a vCard from your file system.',
  'LBL_INSTITUCION' => 'Institucion',
  'LBL_NUMERODECUENTA' => 'Numero de Cuenta',
  'LBL_SALDOPROMEDIO' => 'Saldo Promedio',
  'LBL_TIEMPODECONOCERLOANO' => 'Tiempo de Conocerlo Año',
  'LBL_OPINION' => 'Opinion',
  'LBL_FECHAAPERTURA' => 'Fecha Apertura',
  'LBL_LINEA_DE_CREDITO' => 'Linea de Credito',
  'LBL_SUCURSAL' => 'sucursal',
  'LBL_CURRENCY' => 'Moneda',
  'LBL_SALDO_PROMEDIO' => 'Saldo Promedio',
  'LBL_TIPO_DE_CUENTA' => 'Tipo de Cuenta',
  'LBL_LINEA_CREDITO' => 'Línea de Crédito',
);
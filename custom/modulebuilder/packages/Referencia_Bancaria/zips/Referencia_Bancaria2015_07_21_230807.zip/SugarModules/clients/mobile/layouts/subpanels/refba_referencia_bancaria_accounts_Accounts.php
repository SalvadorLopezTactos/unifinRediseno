<?php
// created: 2015-06-08 19:55:59
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);

$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_REFBA_REFERENCIA_BANCARIA_TITLE',
  'context' => 
  array (
    'link' => 'refba_referencia_bancaria_accounts',
  ),
);
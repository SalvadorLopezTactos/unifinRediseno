<?php
// created: 2015-07-21 23:08:07
$dictionary["Account"]["fields"]["refba_referencia_bancaria_accounts"] = array (
  'name' => 'refba_referencia_bancaria_accounts',
  'type' => 'link',
  'relationship' => 'refba_referencia_bancaria_accounts',
  'source' => 'non-db',
  'module' => 'RefBa_Referencia_Bancaria',
  'bean_name' => 'RefBa_Referencia_Bancaria',
  'vname' => 'LBL_REFBA_REFERENCIA_BANCARIA_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'refba_referencia_bancaria_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
